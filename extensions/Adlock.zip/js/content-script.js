(function () {
  'use strict';

  /** @module General-purpose utilities
   *
   * Most of these functions/types should be placed somewhere in more appropriate location.
   */
  /** Just run the given function
   *
   * This is done because this:
   *
   *   run(function () { ...});
   *
   * Reads a bit better than this:
   *
   *   (function () { ... })();
   *
   * */

  function run(fn, ...args) {
    return fn.apply(this, args);
  }

  /**
   * Convert array of 16 byte values to UUID string format of the form:
   * XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX
   */

  const byteToHex = run(() => {
    let byteToHex = new Array(256);

    for (let i = 0; i < 256; i += 1) {
      byteToHex[i] = (i + 0x100).toString(16).substr(1);
    }

    return byteToHex;
  });

  function insertScript(scriptArray) {
    scriptArray.forEach(script => {
      let code = createScript(script);
      document.head.appendChild(code);
    });
  }

  function createScript(scriptString) {
    let code = document.createElement('script');
    code.setAttribute("type", "text/javascript");
    code.innerHTML = scriptString;
    return code;
  }

  chrome.runtime.onMessage.addListener(onMessage);

  function onMessage(request, sender) {
    switch (request.message) {
      case 'blocked-iframe':
        {
          for (let iframe of document.getElementsByTagName('iframe')) {
            if (iframe.src === request.url) {
              iframe.style.display = 'none';
            }
          }
        }
        return;
    }
  }

  run(function () {
    chrome.runtime.sendMessage({
      message: 'content-script'
    }, function (resp) {
      if (resp.content) {
        insertScript(resp.content);
      }
    });
  });

}());
