(function() {
	self.adProtect = true;
	Object.defineProperties(window, {
		uabpdl: { value: true },
		uabDetect: { value: true }
	});
})();
