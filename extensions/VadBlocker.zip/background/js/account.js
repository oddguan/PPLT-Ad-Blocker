var Account = {
    _inited: false,
    _blockedAds: {},
    _adblockerInfo: {},
    _maxRatio: 0.5,
    // Variable que controla si esta instalada la extension que activa modo ilimitado
    _unlimitedByExtension: false,
    getBlockedAdsAmount: function () {
        var today = moment().format('YYYY/MM/DD');

        if (this._blockedAds.date === today) {
            return this._blockedAds.amount;
        } else {
            return 0;
        }
    },
    incrementBlockedAdsAmount: function () {
        var today = moment().format('YYYY/MM/DD');

        if (!this._inited) {
            // Si todavia no inializo no suma, porque sino se bugea y bloquea mas de lo que podria
            logger.debug('[account.incrementBlockedAdsAmount] No incrementa porque no se inicializo');
            return;
        }

        logger.debug('[account.incrementBlockedAdsAmount] Incrementando cantidad de bloqueos del dia');
        if (this._blockedAds.date === today) {
            this._blockedAds.amount++;
        } else {
            this._blockedAds.date = today;
            this._blockedAds.amount = 1;
        }

        if (!this.canBlock()) {
            logger.debug('[account.incrementBlockedAdsAmount] Deshabilitando adblocker, se llego al limite');
            this.updateAdblockerStatus(false);
        }
    },
    getMaxBlock: function () {
        // Controlar si tiene algun plan activo
        var activePlan = app.getActivePlan();
        if (activePlan) {
            if (activePlan.plan_id === 1) {
                // Plan FREE, ilimitado de manera temporal
                return null;
            } else if (activePlan.plan_id === 2) {
                // Plan PREMIUM, ilimitado
                return null;
            }
        }

        // Controlar FLUJOS. Importante. Flujo=null indica que es ilimitado
        var adblockerFlowId = this._adblockerInfo.adblocker_flow_id;
        if (adblockerFlowId !== 1) {
            return null;
        }

        // Tiene instalada la extension
        if (this._unlimitedByExtension) {
            return null;
        }

        // Controlar si ya tiene un promedio de bloqueos diario
        var average = this._adblockerInfo.ads_blocked_average;
        if (!average) {
            return null;
        }

        // Apply ratio
        var max = Math.floor(average * this._maxRatio);

        return max;
    },
    canBlock: function () {
        var max = this.getMaxBlock();
        var blockedToday = this.getBlockedAdsAmount();

        var canBlock = max === null || blockedToday < max;

        return canBlock;
    },
    init: function (firstRun, callback) {
        var self = this;
        if (firstRun) {
            // Se acaba de registrar, intento levantar la cookie
            logger.debug('[account.init] Inicializado cantidad de bloqueos desde cookie');
            chrome.cookies.get({
                url: configServer.cookies.blockCountCache.url,
                name: configServer.cookies.blockCountCache.name
            }, function (cookie) {
                if (cookie && cookie.value) {
                    // Encontre cookie con bloqueos previos
                    var value = parseInt(cookie.value);
                    self._blockedAds = {
                        date: moment().format('YYYY/MM/DD'),
                        amount: value
                    };
                } else {
                    self._blockedAds = {};
                }

                self.sync(function () {
                    self.checkUnlimitedByExtension(true, function() {
                        self._inited = true;
                        return callback();
                    });
                });
            });
        } else {
            // No es la primera vez, procedimiento normal. Levanto ultimos bloqueos desde el storage
            logger.debug('[account.init] Inicializado cantidad de bloqueos desde storage');
            chrome.storage.local.get('blockedAds', function (response) {
                self._blockedAds = response && response.blockedAds ? response.blockedAds : {};
                self.sync(function () {
                    self.checkUnlimitedByExtension(true, function() {
                        self._inited = true;
                        return callback();
                    });
                });
            });
        }
    },
    sync: function (callback) {
        logger.debug('[account.sync] Resincronizar cuenta');
        var self = this;
        webService.get('user/adblocker', function (response) {
            // Guardar la info del bloqueador en memoria
            self._adblockerInfo = response.data;
            // Re-sincronizar listado de planes
            app.getPlans(true, function () {
                // Actualiza el estado del bloqueador
                var currentStatus = self.canBlock();
                logger.debug('[account.sync] Actualizo el estado del adblocker');
                self.updateAdblockerStatus(currentStatus, function () {
                    return callback();
                });
            });
        }, function () {
            logger.error('[account.sync] Error obteniendo informacion del Adblocker. Reintentando en 30 segundos');
            // Es importante bindear el contexto, ya que en el timeout se pierde y cuando obtiene el SELF
            // Crashea porque las funciones no estan definidas
            return setTimeout(self.sync.bind(self), 30000, callback);
        });
    },
    saveBlocked: function () {
        // If acc is not inited yet, do not save, otherwhise will write empty data
        if (!this._inited) {
            return;
        }

        var self = this;
        chrome.storage.local.set({
            blockedAds: this._blockedAds
        }, function () {
            logger.debug('[account.saveBlocked] Guardado cantidad de bloqueos');
            chrome.cookies.set({
                url: configServer.cookies.blockCountCache.url,
                name: configServer.cookies.blockCountCache.name,
                secure: true,
                value: '' + (self._blockedAds.amount || 0), // convierto a string
                expirationDate: moment().add(1, 'day').startOf('day').unix() // la fecha de expiracion es el inicio de mañana
            }, function (response) {});
        });
    },
    updateAdblockerStatus: function (status, callback) {
        if (status) {
            // Reactivar adblocker
            // Controla si el bloqueador estaba deshabilitado por el limite
            handler.getBlockerStatus({}, null, function (response) {
                // Si estaba deshabilitado, reactiva.
                if (response && response.limitReached) {
                    logger.debug('[account.updateAdblockerStatus] Reactivando bloqueador');
                    handler.setBlockerStatus({
                        status: true,
                        limitReached: false
                    }, null, function () {
                        if (callback) {
                            callback();
                        }
                    });
                } else {
                    logger.debug('[account.updateAdblockerStatus] El bloqueador ya se encontraba activo');
                    if (callback) {
                        callback();
                    }
                }
            });
        } else if (!status) {
            // Desactivar adblocker
            logger.debug('[account.updateAdblockerStatus] Desactivando bloqueador');
            handler.setBlockerStatus({
                status: false,
                limitReached: true
            }, null, function () {
                if (callback) {
                    callback();
                }
            });
        }
    },
    // Metodo que envia un mensaje a la extension a verificar si esta instalada, se actualiza el flag en cada pregunta
    checkUnlimitedByExtension: function (onInit, callback) {
        var self = this;

        // No permitir que esto corra hasta que no inicializo, sino el init y esto corren a la vez
        if (!self._inited && !onInit) {
            if (callback) {
                return callback();
            } else {
                return;
            }
        }

        var set = function (status) {
            if (self._unlimitedByExtension !== status) {
                logger.debug('[account.checkUnlimitedByExtension] Seteando valor a ' + status);
                self._unlimitedByExtension = status;
                self.updateAdblockerStatus(self.canBlock(), function() {
                    if (callback) {
                        return callback();
                    }
                });
            } else {
                if (callback) {
                    return callback();
                }
            }
        };

        app.getExtensions(false, function (response) {
            if (!response || !response.extensions) {
                return set(false);
            }

            var safebrowsingExt = response.extensions.find(function (ext) {
                return ext.extension_key === 'safebrowsing';
            });

            if (!safebrowsingExt) {
                return set(false);
            }

            Communication.sendMessage(safebrowsingExt.extension_id, {
                action: 'getSearchProvider'
            }, function (response) {
                if (response && response.searchProvider && response.searchProvider.recommended) {
                    set(true);
                } else {
                    set(false);
                }
            });
        });
    }
};