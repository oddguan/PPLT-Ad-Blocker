'use strict';

var app = {
    _extensions: null,
    _plans: null,
    _activePlan: null,
    setExtensions: function (extensions) {
        this._extensions = extensions;
    },
    getExtensions: function (force, callback) {
        var self = this;

        /* Si estan en memoria y no me pidio forzado directamente las retorna */
        if (!force && this._extensions) {
            return callback({
                extensions: this._extensions
            });
        }

        webService.get('extension', function (result) {
            logger.debug('Se obtuvo el listado de extensiones desde la API');

            if (result && result.data) {
                self._extensions = result.data;

                return callback({
                    extensions: self._extensions
                });
            }

            return callback({
                extensions: null
            });
        }, function (err) {
            logger.warn('No se pudo obtener el listado de extensiones');
            return callback({
                extensions: null
            });
        });
    },
    getActivePlan: function () {
        var session = webService.getSession();

        // Controlo que no se haya deslogeado, en ese caso, desactivo el plan activo
        if (!session || !session.authorized_token) {
            this._activePlan = null;
        }

        return this._activePlan;
    },
    setPlans: function (plans) {
        var activePlan = null;

        // Si hay planes, buscar plan activo.
        if (plans && plans.length) {
            for (var i = 0; i < plans.length; i++) {
                if (plans[i].active) {
                    activePlan = plans[i];
                }
            }
        }

        // Setear en memoria
        this._plans = plans;
        this._activePlan = activePlan;
    },
    // Consulta los planes por los cuales el usuario fue pasando
    getPlans: function (force, callback) {
        logger.debug('Obteniendo planes...');

        var self = this;
        var localPlans = self._plans;

        // Si no esta logeado, desactiva los planes
        var session = webService.getSession();
        if (!session || !session.authorized_token) {
            if (localPlans) {
                self.setPlans(null);
            }

            return callback(null);
        }

        // Si no esta forzado retorna los planes almacenados en memoria
        if (!force && localPlans) {
            return callback(localPlans);
        }

        // Al estar forzado consulta con la API
        webService.get('account/plan', function (response) {
            var plans = null;
            
            if (response && response.data) {
                plans = response.data;
            }

            self.setPlans(plans);
            
            return callback(plans);
        }, function (err) {
            /* Si fallo reintenta en 30 segundos */
            logger.debug('Error obteniendo planes. Reintentando en 30 segundos');
            setTimeout(function () {
                self.getPlans(force, callback);
            }, 30000);
        });
    },
    // Envia un PING diario a la API
    sendPing: function () {
        var currentDate = moment().utc().format('YYYY-MM-DD'); // Convierto a UTC para que este en sintonia con el server
        var session = webService.getSession();
        var uei;

        if (session && session.extension && session.extension.user_extension_id) {
            // Forma nueva, saca de la sesion
            uei = session.extension.user_extension_id;
        } else {
            // Forma vieja, lo agarra del localStorage
            uei = localStorage.getItem('user_extension_id');
        }

        // Obtiene la fecha del último ping
        chrome.storage.sync.get('pingEvent', function (data = {}) {
            var lastPingEvent = data.pingEvent;

            if (lastPingEvent && lastPingEvent == currentDate) {
                logger.debug('El evento ping ya fue enviado hoy');
                return null;
            }

            logger.debug('El evento aun no se envio. Enviando evento ping para el ' + currentDate);

            // Envia el evento
            webService.post('event', {
                event_type: 'PING_1_DAY',
                uei: uei
            }, function (apiResponse) {
                chrome.storage.sync.set({
                    pingEvent: currentDate
                }, function () {
                    logger.debug('Evento PING almacenado');
                });
            }, function (err) {
                logger.error('Error enviando evento ping');
            });
        });
    },
    logout: function (callback) {
        var session = webService.getSession();

        // Si ya esta deslogeado, no tengo que hacer nada
        if (!session || !session.authorized_token) {
            return callback(session);
        }

        logger.debug('[app.logout] Cerrando sesion en la API');
        webService.delete('extension/logout', function () {
            session = webService.getSession();
            // Eliminar Cookie de sesion, por si queda una sesion abierta
            logger.debug('[app.logout] Eliminando Cookie de sesion de cuenta');
            chrome.cookies.remove({
                url: configServer.cookies.accountToken.url,
                name: configServer.cookies.accountToken.name
            }, function () {
                // Resetear el listado de planes
                logger.debug('[app.logout] Re-sincronizando la cuenta');
                Account.sync(function () {
                    return callback(session.authorized_token);
                })
            });
        }, function () {
            logger.error('[app.logout] Error cerrando sesion en la API');
            var session = webService.getSession();
            return callback(session.authorized_token);
        });
    }
};