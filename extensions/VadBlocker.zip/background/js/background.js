'use strict';

var isUpdated = false;
