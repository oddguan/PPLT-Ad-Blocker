var Communication = {
    broadcast: function (message, callback) {
        var self = this;
        logger.debug('[communication.broadcast] Broadcast iniciado');
        app.getExtensions(null, function (response) {
            if (response && response.extensions && response.extensions.length) {
                var extensions = response.extensions;
                var total = extensions.length;
                var totalReady = 0;

                // Control de que se envio a todas las extensiones
                var cb = function () {
                    totalReady++;
                    if (total === totalReady) {
                        logger.debug('[communication.broadcast] Broadcast terminado');
                        return callback();
                    }
                };

                // Enviar mensaje a todas las extensiones
                for (var i = 0; i < extensions.length; i++) {
                    var extension = extensions[i];
                    self.sendMessage(extension.extension_id, message, cb);
                }
            }
        });
    },
    sendMessage: function (extensionId, message, callback) {
        if (!extensionId) {
            return callback(null);
        }

        logger.debug('[communication.sendMessage] Enviando mensaje a: ' + extensionId);
        chrome.runtime.sendMessage(extensionId, message, function (response) {
            var error = chrome.runtime.lastError;
            if (!error && response && !jQuery.isEmptyObject(response)) {
                logger.debug('[communication.sendMessage] Llego respuesta extension: ' + extensionId);
                return callback(response);
            } else {
                logger.debug('[communication.sendMessage] No llego respuesta de la extension: ' + extensionId);
                return callback(null);
            }
        });
    },
};