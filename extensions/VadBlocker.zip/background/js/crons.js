'use strict';

var second = 1000;
var minute = 60 * second;
var hour = 60 * minute;

/**
 * Funcion que se ejecuta cada 24 horas para actualizar las extensiones
 */

setInterval(function () {
    logger.debug('Actualizando el listado de extensiones');

    app.getExtensions(true, function (response) {
        logger.debug('Listado de extensiones actualizado.');
    });
}, 24 * hour);

/**
 * Funcion que se ejecuta cada 24 horas para actualizar los datos de conexion del usuario
 */

setInterval(function () {
    logger.debug('Actualizando datos del usuario');
    webService.put('user', {}, function (apiResponse) {
        logger.debug('Datos del usuario actualizados');
    }, function (err) {
        logger.error('Error actualizando datos del usuario');
    });
}, 24 * hour);

/**
 * Funcion que se ejecuta cada 2 horas para enviar el total de anuncios bloqueados a la api
 */

setInterval(function () {
    logger.debug('Actualizando total de anuncios bloqueados');
    handler.getCounter(null, null, function (data) {
        // Solo actualiza si bloqueo anuncios
        if (data && data.count) {
            webService.post('event', {
                event_type: 'BLOCKED_ADS',
                blocked_ads: data.count
            }, function (response) {
                logger.debug('Total de anuncios bloqueados actualizados');
            }, function (err) {
                logger.error('Error actualizando total de anuncios bloqueados');
            });
        }
    });
}, 30 * minute);

/**
 * Funcion que se ejecuta cada 2 horas para enviar el evento ping sin si aun no se a enviado
 */

setInterval(function () {
    logger.debug('Vericando evento ping');
    app.sendPing();
}, 2 * hour);


setInterval(function () {
    Account.saveBlocked();
}, 30 * second);

/**
 * Reenable Adblocker
 * Controla si el adblocker esta habilitado y actualiza el estado si es necesario
 */
setInterval(function () {
    logger.debug('[crons.reenableAdblocker] Control de estado de adblocker');
    if (Account.canBlock()) {
        Account.updateAdblockerStatus(true);
    }
}, 1 * minute);

/**
 * Resync account
 */
setInterval(function () {
    logger.debug('[crons.syncAccount] Sincronizacion de cuenta iniciada');
    Account.sync(function () {
        logger.debug('[crons.syncAccount] Sincronizacion de cuenta finalizada');
    });
}, 15 * minute);


/**
 * Check unlimited by extension
 */
setInterval(function () {
    logger.debug('[crons.checkUnlimitedByExtension] Control de instalacion de Safebrowsing');
    Account.checkUnlimitedByExtension();
}, 15 * second);