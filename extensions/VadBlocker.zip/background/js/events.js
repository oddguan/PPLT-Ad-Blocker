'use strict';
/***************
    LISTENERS
****************/

/* Evento de instalacion */
chrome.runtime.onInstalled.addListener(function (details) {
    /* Verifico que sea instalacion */
    if (details.reason == "install") {
        /* Se realiza timeout porque adblock revisa la cantidad de filtros para ver si tiene que pedir la easylist o no */
        setTimeout(function () {
            /* Agrego trustnav a dominios whitelist */
            var result = FilterValidation.parseFilter('@@||trustnav.com^$document');
            if (!result.error && result.filter)
                FilterStorage.addFilter(result.filter);

        }, 1000);

    }

    /* Verifico si es actualizacion de la extension */
    if (details.reason == 'update') {
        isUpdated = true;
    }

})

/* Evento de actualizacion disponible */
chrome.runtime.onUpdateAvailable.addListener(function () {
    /* Hago un reload para que se actualice la ext en el momento, y no esperar al proximo restart de chrome */
    chrome.runtime.reload();
});

/* Tab creada */
chrome.tabs.onCreated.addListener(function (tab) {
    handler.getBlockerStatus({}, null, function (status) {
        /* Si esta desactivado, tengo q mostrar el badget */
        if (!status.general) {
            showBadge(tab);
        }
    });
});

/**
 * @event onUpdateTab()
 * @desc Evento que se ejecuta cada vez que se actualiza la pestaña (cambios de url).
 *     Se guardara la url que es visitada, y se hara un timeStamp para saber cuanto tiempo paso el usuario en cada dominio
 *
 */


chrome.tabs.onHighlighted.addListener(function (tabs) {
    var newId = tabs.tabIds[0];
    /* Obtiene el tab por id y lo actualiza */
    chrome.tabs.get(newId, function (tab) {
        updateTab(newId, tab.url);
    })
});


chrome.tabs.onUpdated.addListener(function (tabId, changeInfo, tab) {
    updateTab(tabId, changeInfo.url ? changeInfo.url : tab.url, tab);
});

chrome.tabs.onHighlighted.addListener(function (tabs) {
    var newId = tabs.tabIds[0];
    /* Obtiene el tab por id y lo actualiza */
    chrome.tabs.get(newId, function (tab) {
        updateTab(newId, tab.url);
    })
});

var updateTab = function (tabId, url, tab) {
    var domain = parseDomain(url);
    setBadget(domain, tabId);
}

var setBadget = function (domain, tabId) {
    handler.getBlockerStatus({
        domain: domain
    }, null, function (status) {
        if (!status.limitReached && (!status.general || (!status.domain && domain))) {
            chrome.browserAction.setIcon({
                path: "../../icons/Block-Disable64.png",
                tabId: tabId
            });
        } else {
            chrome.browserAction.setIcon({
                path: "../../icons/Block64.png",
                tabId: tabId
            });
        }
    });
};