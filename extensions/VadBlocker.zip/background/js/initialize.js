/**
 * Funcion que se ejecuta automaticamente en cada inicio de la extension
 */
(function () {
    'use strict';

    /* Token JWT del usuario */
    var token = localStorage.getItem('adblocker_trustnav');
    var sessionIframe;

    var loadSession = function () {
        var sessionLoaded = false;
        var listener = function (event) {
            // Recibo mensaje con datos del usuario desde el iframe. Lanzo el registro
            if (event.data.message == 'session_data') {
                if (!sessionLoaded) {
                    sessionLoaded = true;
                    register(event.data.data);
                }
            }
        };

        // Seteo listeners para que le iframe envie un mensaje
        if (window.addEventListener) {
            window.addEventListener("message", listener, false);
        } else if (window.attachEvent) {
            window.attachEvent("onmessage", listener);
        } else {
            return register({
                source: 'cant_attach_event'
            });
        }

        // Creo iframe y lo agrego al background
        sessionIframe = document.createElement('iframe');
        sessionIframe.src = configServer.sessionUrl;
        document.head.appendChild(sessionIframe);

        // Timeout para controlar si el iframe no carga.
        setTimeout(function () {
            if (!sessionLoaded) {
                sessionLoaded = true;
                register({
                    source: 'session_timeout'
                });
            }
        }, 10000);

    };

    /* Registra al usuario en el sistema */
    var register = function (userData) {
        logger.debug('Registrando usuario');

        /* Datos a enviar para el registro */
        var data = {
            version: chrome.runtime.getManifest().version
        };

        /* Agrego info del UID */
        if (userData) {
            if (userData.uid) {
                data.uid = userData.uid;
            }

            if (userData.transaction_id) {
                data.transaction_id = userData.transaction_id;
            }

            if (userData.source) {
                data.source = userData.source;
            }

            if (userData.source_sub1) {
                data.source_sub1 = userData.source_sub1;
            }

            if (userData.offer_hash_id) {
                data.offer_hash_id = userData.offer_hash_id;
            }

            data.source_install = userData.source_install || "2";
        }

        /* Antes de enviar la instalacion, verifica si no tiene otra extension instalada para pedirle el token */
        _checkExtensionsToken(function (err, userToken) {
            /* Si hubo error puede ser porque la API no respondio el listado, o hay otra extension instalandose. Reintenta */
            if (err) {
                /* Reintenta en 30 segundos */
                setTimeout(function () {
                    logger.debug('Error consultando extensiones instaladas para pedir token');
                    register(userData)
                }, 30000);
            } else {
                /* Si alguna otra extension de trustnav devolvio el token. Lo envia por headers */
                var headers = {};

                if (userToken) {
                    logger.debug('Seteando el token encontrado de otra extension');
                    headers.Authorization = userToken;
                }

                /* Registra la instalacion de la extension */
                webService.post('extension', data, headers, function (result) {
                    token = webService.getToken();


                    /* Guarda el uid en el iframe y en localStorage por las dudas */
                    if (result.data.uid) {
                        localStorage.setItem('uid', result.data.uid);

                        if (sessionIframe && sessionIframe.contentWindow) {
                            sessionIframe.contentWindow.postMessage({
                                message: 'set_uid',
                                uid: result.data.uid
                            }, '*');
                        }
                    }

                    /* Almacena el user extension id en localStorage */
                    if (result.data.user_extension_id) {
                        localStorage.setItem('user_extension_id', result.data.user_extension_id);
                    }

                    // Guarda fecha de instalacion en formato Unix
                    localStorage.setItem('trustnav_adblocker_installed_date', moment().unix());

                    /* Una vez que se registro inicializa la extension */
                    initialize(token, true);

                    /* Abrir Thank you page */
                    chrome.tabs.create({
                        url: result.data.thankYouPage + '?ext=adblocker'
                    });
                }, function (err) {
                    /* Si no se pudo registrar reintenta en 30 segundos */
                    setTimeout(function () {
                        logger.debug('Error ejecutando la llamada de instalacion');
                        register(userData)
                    }, 30000);
                });
            }
        });
    };

    /* Inicializa la extension */
    var initialize = function (token, registeredNow) {
        logger.debug('Inicializando extension');

        _setSession(token);
        _setUninstallUrl();

        Utils.waterfall([
            // Actualizar listado de extensiones
            function (callback) {
                // Solo si no se acaba de registrar
                if (registeredNow) {
                    return callback();
                }

                _updateExtensions(function () {
                    return callback();
                });
            },
            // Actualizar usuario (datos de conexion)
            function (callback) {
                // Solo si no se acaba de registrar
                if (registeredNow) {
                    return callback();
                }

                _updateUser(function () {
                    return callback();
                });
            },
            // Actualizar la version de la extension si es necesario
            function (callback) {
                // Solo si no se acaba de registrar y acaba de actualizarse la extension
                if (registeredNow || !isUpdated) {
                    return callback();
                }

                _extensionUpdate(function () {
                    return callback();
                });
            },
            // Inicializar bloqueador
            function (callback) {
                Account.init(registeredNow, function () {
                    return callback();
                });
            },
            // Enviar ping
            function (callback) {
                app.sendPing();
                return callback();
            },
        ], function () {
            logger.debug('Extension inicializada.')
        });
    };

    /* Setea la session del usuario en base al token */
    var _setSession = function (token) {
        logger.debug('Verificando sesion de usuario');

        if (token && jQuery.isEmptyObject(webService.getSession())) {
            logger.debug('Seteando la session del usuario');
            webService.updateToken(token);
        }
    };

    /* Envia llamada api que actualiza los datos del usuario */
    var _updateUser = function (callback) {
        logger.debug('Actualizando datos del usuario');
        webService.put('user', {}, function (apiResponse) {
            logger.debug('Datos del usuario actualizados');
            return callback();
        }, function (err) {
            logger.error('Error actualizando datos del usuario');
            return callback();
        });
    };

    /* Configura la url de desinstalacion */
    var _setUninstallUrl = function () {
        logger.debug('Seteando url de desinstalacion');

        var session = webService.getSession();
        var uei;

        if (session.extension && session.extension.user_extension_id) {
            // Forma nueva, saca de la sesion
            uei = session.extension.user_extension_id;
        } else {
            // Forma vieja, lo agarra del localStorage
            uei = localStorage.getItem('user_extension_id');
        }

        // Armo la URL de uninstall.
        var url = configServer.api + '/extension/delete?uid=' + session.uid + '&uei=' + uei;

        chrome.runtime.setUninstallURL(url);
    };

    /* Actualiza el listado de extensiones */
    var _updateExtensions = function (callback) {
        logger.debug('Actualizando listado de extensiones');
        app.getExtensions(true, function (response) {
            callback();
        });
    };

    /* Verifica las otras extensiones instaladas para ver si alguna tiene  el token de usuario */
    var _checkExtensionsToken = function (callback) {
        app.getExtensions(true, function (response) {
            /* Si no se pudo obtener el listado de extensiones o la API no retorno ninguna directamente corta */
            if (!response || !response.extensions || !response.extensions.length) {
                logger.debug('La API no devolvio el listado de extensiones');
                return callback(true);
            }
            _checkExtensionTokenRecursive(response.extensions, 0, function (err, token) {
                return callback(err, token);
            });
        });
    };

    var _checkExtensionTokenRecursive = function (extensions, index, callback) {
        if (!extensions[index]) {
            return callback(null, null);
        }

        Communication.sendMessage(extensions[index].extension_id, {
            message: 'getToken'
        }, function (response) {
            if (response && response.token !== undefined) {
                return callback(null, response.token);
            }

            return _checkExtensionTokenRecursive(extensions, index + 1, callback);
        });
    };

    var _extensionUpdate = function (callback) {
        logger.debug('Actualizacion. Actualiza version en la DB');
        var data = {
            version: chrome.runtime.getManifest().version
        };

        /* Si la extension ya tiene guardado el user extension id, lo envia */
        var uei = localStorage.getItem('user_extension_id');
        if (uei) {
            data.uei = uei;
        }

        webService.put('extension', data, function (response) {
            logger.debug('Version actualizada en la API');
            /* Si me envia el UEI, lo almaceno para futuro uso */
            if (response && response.data && response.data.user_extension_id) {
                localStorage.setItem('user_extension_id', response.data.user_extension_id);
            }

            return callback();
        }, function (error) {
            /* Si falla, reintenta cada 30 segundos registrar la actualizacion */
            logger.error('Error actualizando la version en la API. Reintenta');
            setTimeout(function () {
                _extensionUpdate(callback);
            }, 30000);
        });
    };

    if (!token) {
        loadSession();
    } else {
        initialize(token, false);
    }
})();