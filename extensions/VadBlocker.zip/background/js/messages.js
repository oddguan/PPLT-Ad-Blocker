'use strict';

var scopeStats = trustnavModules.stats;
var Filter = trustnavModules.filter.Filter;
var FilterStorage = trustnavModules.filterStorage.FilterStorage;
var FilterValidation = trustnavModules.filterValidation;

var handler = {
    // -------------------------------------------------------------------------------------
    // SESSION
    // -------------------------------------------------------------------------------------
    checkLogged: function (message, request, callback) {
        var session = webService.getSession();
        if (session.authorized_token) {
            callback({
                name: session.account_name,
                email: session.account_email,
                picture: session.account_avatar_url,
                logged: true
            });
        } else {
            callback({
                logged: false
            });
        }
    },
    getSession: function (message, request, callback) {
        return callback({
            session: webService.getSession(),
            token: webService.getToken()
        });
    },
    login: function (message, request, callback) {
        logger.debug('[handler.login] Ejecutando login');
        var hash = message.hash;
        webService.post('extension/login', {
            login_hash: hash
        }, function () {
            logger.debug('[handler.login] Login terminado');
            // Re-sincronizar cuenta
            Account.sync(function () {
                var session = webService.getSession();
                return callback(session.authorized_token);
            });
        }, function (err) {
            logger.error('[handler.login] Error realizando login');
        });
    },
    logout: function (message, request, callback) {
        logger.debug('[handler.logout] Ejecutando logout');
        app.logout(function (session) {
            logger.debug('[handler.logout] Broadcast al resto de las extensiones');
            Communication.broadcast({
                action: 'logout'
            }, function () {
                logger.debug('[handler.logout] Logout terminado');
                return callback(session);
            });
        });
    },
    refreshSession: function (message, request, callback) {
        logger.debug('Refrescando sesion');
        webService.put('user', {}, function (apiResponse) {
            logger.debug('Refrescando planes del usuario');
            app.getPlans(true, function () {
                return callback({
                    session: webService.getSession(),
                    token: webService.getToken()
                });
            });
        }, function (err) {
            logger.error('Error actualizando datos del usuario');
        });
    },
    // -------------------------------------------------------------------------------------
    // POPUP-BLOCKER
    // -------------------------------------------------------------------------------------
    /**
     * Cambiar el estado del bloqueador de popups en general o para un dominio en particular
     * @param {Object}              message                 El mensaje que contiene el dominio (si se requiere) y el estado
     *                              -- message.domain       El dominio - solo se envía si se quiere actualizar el estado para el dominio en particular
     *                              -- message.status       El estado - true/false
     * @param {-}                   request                 No se utiliza
     * @param {setPopupNotificationCallback}  callback                Callback de respuesta
     */
    /**
     * @callback setPopupNotificationCallback
     * @param {Boolean}             Siempre llega null, no retorna información
     */
    setPopUpNotificationStatus: function (message, request, callback) {
        /* Cambiar el estado para uno en particular */
        if (message.domains && message.domains.length) {
            chrome.storage.sync.get('disabledPopUpDomainNotification', function (data) {
                var domains = data.disabledPopUpDomainNotification;

                if (!domains) {
                    domains = {};
                }

                /* Si me manda false, pide volver a activar las notificaciones */
                if (!message.status) {
                    for (var domain of message.domains) {
                        delete domains[domain];
                    }

                    chrome.storage.sync.set({
                        'disabledPopUpDomainNotification': domains
                    }, function () {
                        return callback();
                    });
                }
                /* Me pide bloquear notificaciones para un sitio */
                else {
                    /* Lo bloqueo y guardo */
                    for (var domain of message.domains) {
                        domains[domain] = true;
                    }

                    chrome.storage.sync.set({
                        'disabledPopUpDomainNotification': domains
                    }, function () {
                        return callback();
                    });
                }
            });
        }
        /* Cambiar el estado para todos los sitios */
        else {
            chrome.storage.sync.set({
                'disabledPopUpNotification': message.status
            }, function () {
                return callback();
            });
        }
    },
    /**
     * Obtener el estado del bloqueador de Popups
     * @param {Object}              message                 El mensaje que contiene el dominio (si se requiere)
     *                              -- message.domain       El dominio - solo se envía si se quiere obtener el estado para el dominio en particular
     * @param {-}                   request                 No se utiliza
     * @param {getPopupNotificationCallback}  callback                Callback de respuesta
     */


    /**
     * @callback getPopupNotificationCallback
     * @param {Object}              response
     *                              -- reponse.status {Boolean}         El estado general del bloqueador - true habilitado, false deshabilitado
     */
    getPopUpNotificationStatus: function (message, request, callback) {
        chrome.storage.sync.get('disabledPopUpNotification', function (data = {}) {
            /* Las notificaciones estan activadas */
            if (!data.disabledPopUpNotification) {
                /* Si me pidio para un sitio, evaluo si para el sitio estan desactivadas */
                if (message.domain) {
                    chrome.storage.sync.get('disabledPopUpDomainNotification', function (dataDomain = {}) {
                        /* No hay ningun sitio bloqueado */
                        if (!dataDomain.disabledPopUpDomainNotification) {
                            return callback({
                                status: true
                            });
                        } else if (!dataDomain.disabledPopUpDomainNotification[message.domain]) {
                            /* El sitio no esta bloqueado */
                            return callback({
                                status: true
                            });
                        } else {
                            /* El sitio esta bloqueado */
                            return callback({
                                status: false
                            });
                        }
                    });
                }
                /* No me pidio solo un sitio, respondo que las globales estan activadas */
                else {
                    return callback({
                        status: true
                    });
                }
            }
            /* Estan desactivadas las notificaciones */
            else {
                return callback({
                    status: false
                });
            }
        });
    },
    /**
     * Obtener el listado de dominios con el bloqueador de popups deshabilitado
     * @param {Object}              message                 No se utiliza
     * @param {-}                   request                 No se utiliza
     * @param {getPopupDisabledNotificationCallback}  callback                Callback de respuesta
     */


    /**
     * @callback getPopupDisabledNotificationCallback
     * @param {Object}              response
     *                              -- reponse.domains {Array}         Arreglo de dominios donde el bloqueador de popups esta deshabilitado
     */
    getPopUpDisabledNotification: function (message, request, callback) {
        chrome.storage.sync.get('disabledPopUpDomainNotification', function (dataDomain = {}) {
            var domains = [];
            if (dataDomain.disabledPopUpDomainNotification) {
                for (var domain in dataDomain.disabledPopUpDomainNotification) {
                    domains.push(domain);
                }
            }
            return callback({
                domains: domains
            });
        });
    },

    // -------------------------------------------------------------------------------------
    // ADBLOCKER
    // -------------------------------------------------------------------------------------

    /**
     * Cambiar el estado del bloqueador
     * @param {Object}              message                 El mensaje que contiene el dominio (si se requiere) y el estado
     *                              -- message.domain       El dominio - solo se envía si se quiere actualizar el estado para el dominio en particular
     *                              -- message.status       El estado - true/false
     * @param {-}                   request                 No se utiliza
     * @param {setBlockerCallback}  callback                Callback de respuesta
     */

    /**
     * @callback setBlockerCallback
     * @param {Boolean}             Siempre llega null, no retorna información
     */
    setBlockerStatus: function (message, request, callback) {
        /* Cambiar el estado para uno en particular */
        if (message.domain) {
            chrome.storage.sync.get('disabledDomainBlocker', function (data) {
                var domains = data.disabledDomainBlocker;
                if (!domains) {
                    domains = {};
                }

                /* Si me manda true, pide volver a activar el dominio */
                if (message.status) {
                    if (message.domain.indexOf('trustnav.com') < 0) {
                        var filter = Filter.fromText("@@||" + message.domain + "^$document");
                        FilterStorage.removeFilter(filter);
                    }

                    delete domains[message.domain];

                    chrome.storage.sync.set({
                        'disabledDomainBlocker': domains
                    }, function () {
                        updateBadget(message.status, message.domain);
                        return callback();
                    });
                }
                /* Si me manda false, pide  desactivar el dominio */
                else {
                    /* Lo bloqueo y guardo */
                    if (message.domain.indexOf('trustnav.com') < 0) {
                        var filter = Filter.fromText("@@||" + message.domain + "^$document");
                        FilterStorage.addFilter(filter);
                    }

                    domains[message.domain] = true;

                    chrome.storage.sync.set({
                        'disabledDomainBlocker': domains
                    }, function () {
                        updateBadget(message.status, message.domain);
                        return callback();
                    });
                }
            });
        }
        /* Cambiar el estado general */
        else {
            var filter = Filter.fromText("@@||" + "*" + "^$document");

            /* Si me manda true, pide volver a activar el dominio */
            if (message.status) {
                FilterStorage.removeFilter(filter);
            } else {
                /* Si me manda false, pide  desactivar el dominio */
                /* Lo bloqueo y guardo */
                FilterStorage.addFilter(filter);
            }

            chrome.storage.sync.set({
                'disabledBlocker': {
                    status: !message.status,
                    limitReached: message.limitReached
                }
            }, function () {
                if (!message.limitReached) {
                    updateBadget(message.status);
                }

                return callback();
            });
        }
    },

    /**
     * Obtener el estado del bloqueador
     * @param {Object}              message                 El mensaje que contiene el dominio (si se requiere)
     *                              -- message.domain       El dominio - solo se envía si se quiere obtener el estado para el dominio en particular
     * @param {-}                   request                 No se utiliza
     * @param {getBlockerCallback}  callback                Callback de respuesta
     */


    /**
     * @callback getBlockerCallback
     * @param {Object}              status
     *                              -- status.general {boolean}         El estado general del bloqueador - true habilitado, false deshabilitado
     *                              -- status.domain {boolean}          El estado general del bloqueador en el dominio (solo si se pide dominio) - true habilitado, false deshabilitado
     */
    getBlockerStatus: function (message, request, callback) {
        chrome.storage.sync.get('disabledBlocker', function (data = {}) {

            if (typeof data.disabledBlocker === Boolean) {
                data.disabledBlocker = {
                    status: data.disabledBlocker,
                    limitReached: false
                };
            }

            var status = {
                general: data.disabledBlocker && data.disabledBlocker.status ? false : true,
                limitReached: data.disabledBlocker && data.disabledBlocker.limitReached ? true : false
            };

            if (message.domain) {
                chrome.storage.sync.get('disabledDomainBlocker', function (dataDomain = {}) {
                    status.domain = dataDomain.disabledDomainBlocker && dataDomain.disabledDomainBlocker[message.domain] ? false : true;
                    return callback(status);
                });
            } else {
                /* No me pidio un sitio, respondo el estado de las globales */
                return callback(status);
            }
        });
    },

    /**
     * Obtener los anuncios bloqueados por pagina
     * @param {Object}              message                 El mensaje que contiene la pagina
     *                              -- message.data         ID de pagina
     * @param {getCounterCallback}  callback                Callback de respuesta
     */

    /**
     * @callback getBlockerCallback
     * @param {Object}            response
     *        {int}               response.count            La cantidad total de anuncios bloqueados
     */
    getCounter: function (message, request, callback) {
        // Si envio un id le envio los anuncios bloqueados en esa pagina, si no los anuncios bloqueados en total.
        if (message && message.data.id) {
            return callback({
                count: scopeStats.getBlockedPerPage(message.data) || 0
            });
        } else {
            return callback({
                count: scopeStats.getTotalBlocked() || 0
            });
        }
    },

    /**
     * Consultar si debe mostrar notificaciones custom
     * @param {Object}              message                 Contiene el nombre de la notificacion
     *                              message.name       Nombre de la notificacion
     */
    getCustomNotificationStatus: function (message, request, callback) {
        var name = message.name;
        var today = moment().format('YYYY/MM/DD');

        chrome.storage.sync.get('customNotificationStatus', function (response) {
            // Variable que decide si se muestra o no
            var status = false;
            // Variable que decide si actualizar el valor en el storage o no
            var updateStorage = false;

            // Leo el estado almacenado
            var notification = {};
            if (response && response.customNotificationStatus && response.customNotificationStatus[name]) {
                notification = response.customNotificationStatus[name];
            }

            if (name === 'happy_with_trustnav') {
                // Solo muestra una vez
                if (!notification.times) {
                    var installedDate = localStorage.getItem('trustnav_adblocker_installed_date');
                    // Si no tengo fecha de instalacion, o paso mas de 7 dias, muestra alerta
                    if (!installedDate || moment().diff(moment.unix(installedDate), 'days') >= 7) {
                        status = true;
                        updateStorage = true;
                    }
                }
            } else if (name === 'installation_success') {
                var url = request.url;
                // Solo muestra si la URL tiene ese parametro
                if (url && url.indexOf('trst_adb_first_time=1') !== -1) {
                    // Solo lo muestra una vez
                    if (notification.times) {
                        status = false;
                    } else {
                        status = true;
                        updateStorage = true;
                    }
                }
            } else if (name === 'limit_reached') {
                // Solo muestra una vez al dia. Solo muestra cuando ya no puede bloquear
                var canBlock = Account.canBlock();
                if (!canBlock && (!notification.date || (moment.unix(notification.date).format('YYYY/MM/DD') !== today))) {
                    status = true;
                    updateStorage = true;
                } else {
                    status = false;
                }
            } else if (name === 'free_trial_daily') {
                // // Se muestra una vez por dia si tiene el plan activo
                // var activePlan = Account.getActivePlan();

                // if ((!Account.isUnlimitedByExtension()) && (activePlan && activePlan.finished_at && moment(activePlan.finished_at).diff(moment(today), 'days') > 0) && (!notification.date || (moment.unix(notification.date).format('YYYY/MM/DD') !== today))) {
                //     status = true;
                //     updateStorage = true;
                // } else {
                //     status = false;
                // }
            } else if (name === 'free_trial_end') {
                // // Se muestra una unica vez, cuando el plan free trial termine
                // var activePlan = Account.getActivePlan();

                // if ((!Account.isUnlimitedByExtension()) && (activePlan && activePlan.finished_at && moment(activePlan.finished_at).diff(moment(today), 'days') == 0) && (!notification.date || (moment.unix(notification.date).format('YYYY/MM/DD') !== today))) {
                //     status = true;
                //     updateStorage = true;
                // } else {
                //     status = false;
                // }
            }

            // Si solicita, actualizo el storage
            if (status && updateStorage) {
                // Control por si no esta definido el objeto (primer guardado)
                var storage = response && response.customNotificationStatus ? response.customNotificationStatus : {};

                // Almacena la fecha de la ultima alerta + cantidad de veces que se mostro
                storage[name] = {
                    times: notification.times ? notification.times + 1 : 1,
                    date: moment().unix()
                };

                // Almacena
                chrome.storage.sync.set({
                    customNotificationStatus: storage
                });
            }

            // Response
            return callback({
                status: status
            });
        });
    },
    /**
     * Obtener las estadisticas de bloqueo del Adblocker
     * @param {Object}              message                  Sin uso
     *                              message.name             Sin uso
     * @param {getAdblockerStatsCallback}  callback                Callback de respuesta
     */

    /**
     * @callback getAdblockerStatsCallback
     * @param {Object}            response
     *        {Object}               response.blocked                    Información de bloqueo
     *        {Int}                         response.blocked.amount      Cantidad de anuncios bloqueados en el dia actual
     *        {Int}                         response.blocked.max         Cantidad de anuncios maximos que puede bloquear. Si es null, es porque no tiene un maximo (es ilimitado)
     *        {Boolean}              reponse.canBlock                    true si puede continuar bloqueando anuncios, false si ya no puede.
     */
    getAdblockerStats: function (message, request, callback) {
        var resp = {
            blocked: {
                amount: Account.getBlockedAdsAmount(),
                max: Account.getMaxBlock(),
            },
            canBlock: Account.canBlock()
        };

        if (resp.blocked.max !== null) {
            resp.blocked.left = resp.blocked.max - resp.blocked.amount;

            if (resp.blocked.left < 0) {
                resp.blocked.left = 0;
                resp.blocked.amount = resp.blocked.max;
            }
        }

        return callback(resp);
    },
    /**
     * Consultar estados publicos del plan actual del usuario
     * @param {Object}              message                  Sin uso
     *                              message.name             Sin uso
     * @param {getCounterCallback}  callback                Callback de respuesta
     */
    getActivePlan: function (message, request, callback) {
        // Obtengo el dia de hoy
        var today = moment().format('YYYY/MM/DD');
        // Obtengo plan actual
        var activePlan = app.getActivePlan();
        // Si la respuesta es null indica que el usuario no tiene planes activos
        var resp = null;

        if (activePlan) {
            resp = {
                plan_name: activePlan.plan_name
            };

            if (activePlan.finished_at) {
                resp.remainingDays = moment(activePlan.finished_at).diff(moment(today), 'days')
            }
        }

        return callback(resp);
    }
};

var externalHandler = {
    getToken: function (message, request, callback) {
        logger.debug('[externalHandler.getToken] Llega mensaje. Envio respuesta');
        return callback({
            token: webService.getToken(),
            installed: true
        });
    },
    isInstalled: function (message, request, callback) {
        logger.debug('[externalHandler.isInstalled] Llega mensaje. Envio respuesta');
        return callback({
            token: webService.getToken(),
            installed: true
        });
    },
    logout: function (message, request, callback) {
        logger.debug('[externalHandler.logout] Realizando logout');
        app.logout(function (session) {
            logger.debug('[externalHandler.logout] Logout finalizado');
            return callback({});
        });
    }
};


/* Escuchar eventos */
chrome.runtime.onMessage.addListener(function (message, request, callback) {
    if (handler[message.action]) {
        handler[message.action](message, request, callback);
        return true;
    }
});

/* Escucha eventos de otras extensiones */
chrome.runtime.onMessageExternal.addListener(function (message, request, callback) {
    var action = message.action || message.message;

    // Solo controla si esta definido el handler
    if (action && externalHandler[action]) {
        logger.debug('Llego un mensaje de otra extension: ' + request.id);

        /* Antes de responder, pide todas las extensiones de memoria / API */
        app.getExtensions(false, function (response) {
            if (!response || !response.extensions || !response.extensions.length) {
                logger.debug('No se pudo obtener el listado de extensiones para responder');
                return callback({});
            }

            /* Verifica si la extension que esta enviando el mensaje percenece a trustnav */
            var result = $.grep(response.extensions, function (extension) {
                return extension.extension_id === request.id;
            });

            /* Si no encontro resultados quiere decir que la extension no pertenece a trustnav */
            if (!result[0]) {
                logger.debug('La extension que envia el mensaje no pertenece a Trustnav');
                return callback({});
            }

            externalHandler[action](message, request, callback);
        });
    }

    return true;
});

/**
 * Actualizar el estado del badge despues de actualizar el estado del bloqueador de anuncios
 * @param {Integer}  status             Estado del bloqueador
 * @param {String}   domain             Dominio en el cual desactivar el bloqueador. (se recibe solo cuando no se trata de cambio de estado global)
 */
var updateBadget = function (status, domain) {
    /* Activar bloqueador */
    if (status) {
        /* Reactivar de manera global */
        if (!domain) {
            /* Tengo que cambiar el badget de todos los tabs */
            chrome.tabs.query({}, function (tabs) {
                for (var tab of tabs) {
                    removeBadge(tab);
                }
            });
        }
        /* Reactivar para un dominio. Busco todas las tabs cuyo dominio sea el que estoy activando */
        else {
            chrome.tabs.query({}, function (tabs) {
                for (var tab of tabs) {
                    var tabDomain = parseDomain(tab.url);
                    if (domain === tabDomain) {
                        removeBadge(tab);
                    }
                }
            });
        }
    } else {
        /* Solicita desactivar */
        /* Desactivar globalmente */
        if (!domain) {
            /* Tengo que cambiar el badget de todos los tabs */
            chrome.tabs.query({}, function (tabs) {
                for (var tab of tabs) {
                    showBadge(tab);
                }
            });
        } else {
            /* Busco todas las tabs que coincida el dominio y les cambio el icono */
            chrome.tabs.query({}, function (tabs) {
                for (var tab of tabs) {
                    var tabDomain = parseDomain(tab.url);
                    if (domain === tabDomain) {
                        showBadge(tab);
                    }
                }
            });
        }
    }
};


/**
 * Mostrar el badge que indica que el bloqueador está desactivado
 * @param {Object}  tab             El objeto de la tab
 */
var showBadge = function (tab) {
    try {
        chrome.browserAction.setIcon({
            path: "../../icons/Block-Disable64.png",
            tabId: tab.id
        });
    } catch (e) {}
}

/**
 * Ocultar el badge que indica que el bloqueador está desactivado
 * @param {Object}  tab             El objeto de la tab
 */
var removeBadge = function (tab) {
    /* Obtengo el dominio del tab en cuestion y me fijo si para ese dominio esta activado el bloqueador.
     * Esto es para prevenir sacar el badget de tabs cuyo dominio esta desactivado, al reactivar de manera global */
    var domain = parseDomain(tab.url);
    handler.getBlockerStatus({
        domain: domain
    }, null, function (status) {
        /* Si esta activado para el dominio de la tab, oculto el badget */
        if (status.domain) {
            try {
                chrome.browserAction.setIcon({
                    path: "../../icons/Block64.png",
                    tabId: tab.id
                });
            } catch (e) {}
        }
    });
}