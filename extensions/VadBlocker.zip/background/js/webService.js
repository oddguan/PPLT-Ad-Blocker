'use strict';

var webService = {
    apiUrl: configServer.api + "/",
    token: null,
    session: {},
    post: function (path, body, headers, callback, errorCallback) {
        this.request(path, 'POST', body, headers, callback, errorCallback);
    },
    get: function (path, headers, callback, errorCallback) {
        this.request(path, 'GET', null, headers, callback, errorCallback);
    },
    put: function (path, body, headers, callback, errorCallback) {
        this.request(path, 'PUT', body, headers, callback, errorCallback);
    },
    delete: function (path, headers, callback, errorCallback) {
        this.request(path, 'DELETE', null, headers, callback, errorCallback);
    },
    request: function (path, method, body, headers, callback, errorCallback) {
        /* Si headers es una funcion, es porque no lo envio y es el callback) */
        if (typeof headers === 'function') {
            // Corro los parametros
            errorCallback = callback;
            callback = headers;
            headers = null;
        }

        var self = this;
        var options = {
            url: this.apiUrl + path,
            method: method,
            headers: {
                'Extension': configServer.extensionKey,
                'X-Extension-Id': chrome.runtime.id,
                'X-Extension-Version': chrome.runtime.getManifest().version
            },
            dataType: 'json',
            contentType: 'application/json; charset=utf-8',
            traditional: true
        };

        if (body) {
            options.data = JSON.stringify(body);
        }

        var uei = localStorage.getItem('user_extension_id');
        if (uei) {
            options.headers['X-User-Extension-Id'] = uei;
        }

        if (this.token) {
            options.headers.Authorization = this.token;
        }

        if (headers) {
            options.headers = $.extend(options.headers, headers);
        }

        $.ajax(options).done(function (data, status, request) {
            if (data) {
                // Si envia un token por response header, lo parseo y actualizo.
                var token = request.getResponseHeader('Authorization');
                if (token) {
                    self.updateToken(token);
                }

                return callback(data);
            } else {
                return errorCallback({
                    message: 'Unknown error'
                });
            }
        }).fail(function (err) {
            if (err && err.responseJSON) {
                return errorCallback(err.responseJSON);
            } else {
                return errorCallback({
                    message: 'Unknown error'
                });
            }
        });
    },
    updateToken: function (newToken) {
        var parsedSession;

        try {
            parsedSession = jwt_decode(newToken);
        } catch (err) {
            logger.crit('[webService.updateToken] Unable to parse JWT Token', {
                code: err.code,
                message: err.message,
                token: newToken
            });
        }

        // Si el token cambio y se pudo parsear, lo actualiza en memoria y en 
        if (parsedSession && parsedSession.id && newToken !== this.token) {
            logger.debug('[webservice.updateToken] Actualizando session.');
            this.setToken(newToken);
            this.setSession(parsedSession);
        }
    },
    getToken: function () {
        return this.token;
    },
    setToken: function (token) {
        this.token = token;
        localStorage.setItem('adblocker_trustnav', token);
    },
    getSession: function () {
        return this.session;
    },
    setSession: function (session) {
        this.session = session;
    }
}