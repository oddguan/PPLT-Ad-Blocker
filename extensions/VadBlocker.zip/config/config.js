var configServer = {
	api: "https://api-production.trustnav.com",
	website: "https://www.trustnav.com",
	accountUrl: "https://account.trustnav.com",
    sessionUrl: 'https://get.trustnav.com/session/index.html',
    extensionKey: 'adblocker',
	extensionType: 'adblocker',
	cookies: {
		blockCountCache: {
			url: 'https://get.trustnav.com/',
			name: 'adblocker_block_count'
		},
		accountToken: {
			url: 'https://account.trustnav.com/',
			name: 'account_token'
		}
	},
	env: {
		production: true
	},
	logger: {
		logLevel: 'info',
		levels: ['debug', 'verbose', 'info', 'warn', 'error', 'crit']
	},
};