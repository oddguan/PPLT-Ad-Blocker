(function () {
    var injectIframeDynamic = function (config) {
        var iFrame = document.createElement("iframe");
        iFrame.style.width = config.width;
        iFrame.style.height = config.height;
        iFrame.style.position = 'fixed';
        iFrame.style.top = '16px';
        iFrame.style.right = '16px';
        iFrame.style.zIndex = '9999999999';
        iFrame.style.borderRadius = '8px';
        iFrame.style.boxShadow = '0 2px 8px 0 rgba(0, 0, 0, 0.3)';
        iFrame.style.backgroundColor = '#ffffff';
        iFrame.style.border = 'solid 1px #d7d7d7';
        iFrame.src = chrome.extension.getURL(config.path);
        iFrame.id = 'trustnav_adb_iframe';

        document.body.insertBefore(iFrame, document.body.firstChild);
    };

    window.addEventListener("message", function (event) {
        if (event && event.data && event.data.message) {
            if (event.data.message === 'trustnav_close_adb_iframe') {
                closeTrustnavIframe(event.data.toClose);
            }
        }
    }, false);

    var closeTrustnavIframe = function () {
        var element = $('#trustnav_adb_iframe');
        if ($(element).length != 0) {
            $(element).remove();
        }
    };

    var notifications = [{
            name: 'installation_success',
            width: '642px',
            height: '245px',
            path: '../../views/notifications/installation_success/index.html',
            executeAfter: function () {}
        }, {
            name: 'limit_reached',
            width: '642px',
            height: '242px',
            path: '../../views/notifications/limit_reached/index.html',
            executeAfter: function () {}
        }
        /*, {
                name: 'free_trial_daily',
                width: '642px',
                height: '242px',
                path: '../../views/notifications/daily/index.html',
                executeAfter: function () {}
            }, {
                name: 'free_trial_end',
                width: '642px',
                height: '242px',
                path: '../../views/notifications/0days/index.html',
                executeAfter: function () {}
            }*/
    ];


    var checkNotification = function (index) {
        var notification = notifications[index];

        if (!notification) {
            return;
        }

        chrome.runtime.sendMessage({
            action: 'getCustomNotificationStatus',
            name: notification.name
        }, function (response) {
            if (response && response.status) {
                injectIframeDynamic({
                    path: notification.path,
                    width: notification.width,
                    height: notification.height
                });
            } else {
                return checkNotification(index + 1);
            }
        });
    };

    checkNotification(0);
}());