// $(document).on("click","#trustnav-open",function() {
//     if (urlBlocked) {
//         $("#trustnav-popBlocker").fadeOut(300, function() {
//              $(this).remove();
//          });
//
//         window.open(urlBlocked[0],urlBlocked[1],urlBlocked[2]);
//     }
// });
//
// $(document).on("click","#trustnav-close",function() {
//     $("#trustnav-popBlocker").fadeOut(300, function() {
//          $(this).remove();
//      });
// });
//
// // $(document).on("mouseenter","#trustnav-popBlocker",function() {
// //     clearTimeout(notificationTimeout);
// // });
// //
// // $(document).on("mouseleave","#trustnav-popBlocker",function() {
// //     notificationTimeout = setTimeout(function () {
// //         $("#trustnav-popBlocker-wrap").fadeOut(300, function() { $(this).remove(); })
// //     }, 3000);
// // });
//
// $(document).on("click","#displayGroup",function() {
//     $(".trustnav-options-group").toggleClass('no-display');
// });
//
// $(document).on("click","#trustnav-no-this-site",function() {
//     var domain = parseDomain(document.domain);
//
//     chrome.runtime.sendMessage({ action: 'setPopUpNotificationStatus', domains : [domain], status : true  }, function(response) {
//         $("#trustnav-popBlocker").fadeOut(300, function() {
//              showNotification = false;
//              $(this).remove();
//          });
//     });
// });
//
// $(document).on("click","#trustnav-no-all-sites",function() {
//     chrome.runtime.sendMessage({ action: 'setPopUpNotificationStatus' , status : true  }, function(response) {
//         $("#trustnav-popBlocker").fadeOut(300, function() {
//              showNotification = false;
//              $(this).remove();
//          });
//     });
// });

$("html").on("click", "a", onHyperLinkClicked); // listen to all link elements's click event
