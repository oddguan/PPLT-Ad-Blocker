var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ?  originalTypeOf : typeOfSymbol;

var _inject = {inject: inject};

var showNotification = true;

var langs = ['en', 'es'];
var userLang = navigator.language.substr(0, 2);

if (langs.indexOf(userLang) < 0) {
    userLang = 'en';
}

(function($) {
    chrome.runtime.sendMessage({ action: 'getBlockerStatus', domain: parseDomain(document.domain) }, function(response) {
        if (response && response.general && response.domain) {
            chrome.runtime.sendMessage({ action: 'getAdblockerStats' }, function (response) {
                if (response.canBlock) {
                    initBlockFunctions();
                }
            });
        }
    });

    var domain = parseDomain(document.domain);
    chrome.runtime.sendMessage({ action: 'getPopUpNotificationStatus', domain : domain}, function(response) {
        if (response)
            showNotification = response.status;
    });

})(jQuery.noConflict(true));
