var jq = $;
var useOriginalOpen = false;

var originalTypeOf = function (obj) {
    return typeof obj;
};

var typeOfSymbol = function (obj) {
    return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
};

function executeCode(code) {
    var s = document.createElement("script");
    var rootDocument = document.documentElement;
    s.textContent = code;
    rootDocument.insertBefore(s, rootDocument.firstChild);

    setTimeout(function () {
        s.parentNode.removeChild(s);
    }, 50);
}

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : { default: obj };
}

function monitorBlocks() {
    window.addEventListener("message", function receiveMessage(event) {
        if (event.data.type && event.data.type == "blockedWindow") {
            var _ret = function () {
                if (self !== top) {
                    //pass the message to parent
                    var parentOrigin = window.location != window.parent.location ? document.referrer : document.location;
                    parent.postMessage({
                        type: "blockedWindow",
                        args: event.data.args
                    }, parentOrigin);
                    return {
                        v: void 0
                    };
                }

                var args = JSON.parse(event.data.args);

                if (showNotification) {
                    showPopupBlockedNotification(args);
                }

                if (useOriginalOpen && urlBlocked) {
                    window.open(urlBlocked[0], urlBlocked[1], urlBlocked[2]);
                }
            }();

            if ((typeof _ret === "undefined" ? "undefined" : _typeof(_ret)) === "object") return _ret.v;
        }
    }, false);
}


function getFrameHtml(htmlFileName) {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.open("GET", chrome.extension.getURL(htmlFileName), false);
    xmlhttp.send();
    return xmlhttp.responseText;
}


var urlBlocked = null;

function showPopupBlockedNotification(args) {
    /* No muestro notificacion cuando sea about:blank, porque sino no la puedo restaurar */
    if (!args || !args[0] || args[0] == 'about:blank')
        return;

    /* Si ya hay una notificacion, no la muestro */
    if (jq("#trustnav_pb_iframe").length)
        return;

    urlBlocked = args;

    /* Inyecto el iframe */
    jq("html").append("<iframe name='trustnav_pb_iframe' id='trustnav_pb_iframe'></iframe>");
    var html = getFrameHtml('../../views/popUpBlockNotification/index.html');

    var doc = document.getElementById('trustnav_pb_iframe').contentWindow.document;
    var body = jq('body', doc);
    body.html(html);
    /* Agrego los eventos necesarios */
    var iframe = jq("#trustnav_pb_iframe").contents();
    var timeout;

    var removeIframe = function () {
        if (jq("#trustnav_pb_iframe").length)
            jq("#trustnav_pb_iframe").remove();
    };
    var setNotificationTimeout = function (t) {
        if (timeout)
            clearTimeout(timeout);
        timeout = setTimeout(function () {
            removeIframe();
            timeout = null;
        }, t);
    };
    setNotificationTimeout(5000);

    iframe.find("#trustnav-open").on('click', function () {
        if (urlBlocked) {
            window.open(urlBlocked[0], urlBlocked[1], urlBlocked[2]);
            removeIframe();
        }
    });

    iframe.find("#trustnav-close").on('click', function () {
        removeIframe();
    });

    iframe.find("#trustnav-popBlocker-wrap").on('mouseenter', function () {
        if (timeout) {
            clearTimeout(timeout);
        }
    });

    iframe.find("#trustnav-popBlocker-wrap").on('mouseleave', function () {
        setNotificationTimeout(3000);
    });


    iframe.find("#displayCloseGroup").on('click', function () {
        iframe.find("#close-group").toggleClass('no-display');
        iframe.find("#open-group").addClass('no-display');
    });

    iframe.find("#displayOpenGroup").on('click', function () {
        iframe.find("#open-group").toggleClass('no-display');
        iframe.find("#close-group").addClass('no-display');
    });


    jq('html').on('click', function () {
        iframe.find(".trustnav-options-group").addClass('no-display');
    })

    iframe.find("#trustnav-no-this-site").on('click', function () {
        var domain = parseDomain(document.domain);
        chrome.runtime.sendMessage({ action: 'setPopUpNotificationStatus', domains: [domain], status: true }, function (response) {
            removeIframe();
            showNotification = false;
        });
    });

    iframe.find("#trustnav-allow-this-site").on('click', function () {
        var domain = parseDomain(document.domain);
        chrome.runtime.sendMessage({
            'action': 'setBlockerStatus',
            'status': false,
            'domain': domain
        }, function (response) {
            if (urlBlocked) {
                window.open(urlBlocked[0], urlBlocked[1], urlBlocked[2]);
                removeIframe();
                showNotification = false;
                useOriginalOpen = true;
            }
        });
    });


    iframe.find("#trustnav-no-all-sites").on('click', function () {
        chrome.runtime.sendMessage({ action: 'setPopUpNotificationStatus', status: true }, function (response) {
            removeIframe();
            showNotification = false;
        });
    });

    // Traducir el iframe
    iframe.find("[tkey]").each(function (i) {
        var key = $(this).attr('tkey');
        var translation = chrome.i18n.getMessage(key);

        jq(this).html(translation);
    });
}


function initBlockFunctions() {
    //paused do not do anything
    var whiteList = {
        "linkedin.com": true,
        "google": true,
        "gmail.com": true,
        "pinterest.com": true,
        "youtube.com": true,
        "facebook.com": true,
        "search.yahoo.com": true,
        "chrome://newtab": true,
        "www.food.com": true,
        "localhost": true
    }
    if (!whiteList[parseDomain(document.domain)]) {
        var code = "(function () {" + _inject.inject.toString() + ";\n          inject();\n        })();";
        executeCode(code);
        monitorBlocks(); // Previously this only ran if window = parent
    }

}

function isOverlayish(el) {
    var winWidth = window.innerWidth;
    var winHeight = window.innerHeight;

    if (/fixed|absolute/.test(el.css('position')) && el.outerWidth() >= winWidth * 0.6 && el.outerHeight() >= winHeight * 0.75) {
        return true;
    }

    return false;
}

function onHyperLinkClicked(e) {
    var el = jq(this);
    var href = el.attr('href');
    var target = el.attr('target') || '_self';

    if (href && href !== '#' && target !== '_self') {
        //only if has href and open in new tab/window
        if (isOverlayish(el)) {
            e.preventDefault();

            parent.postMessage({
                type: "blockedWindow",
                args: JSON.stringify({
                    "0": href
                })
            }, window.parent.location);
        }
    }
}

function inject() {
    var originalOpenWndFnKey = "originalOpenFunction";
    var originalWindowOpenFn = window.open;
    var originalCreateElementFn = document.createElement;
    var originalAppendChildFn = HTMLElement.prototype.appendChild;
    var originalCreateEventFn = document.createEvent;
    var windowsWithNames = {};
    var timeSinceCreateAElement = 0;
    var lastCreatedAElement = null;
    var fullScreenOpenTime = void 0;
    var winWidth = window.innerWidth;
    var winHeight = window.innerHeight;
    var abd = false;
    var lastBlockTime = void 0;
    var lastBlockCaller = void 0;
    var allowOnce = false;
    var parentOrigin = window.location != window.parent.location ? document.referrer : document.location;
    var parentRef = window.parent;

    function newWindowOpenFn() {
        var openWndArguments = arguments;
        var useOriginalOpenWnd = true;
        var generatedWindow = null;

        function getWindowName(openWndArguments) {
            var windowName = openWndArguments[1];

            if (windowName != null && !["_blank", "_parent", "_self", "_top"].includes(windowName)) {
                return windowName;
            }

            return null;
        }

        function copyMissingProperties(src, dest) {
            var prop = void 0;
            for (prop in src) {
                try {
                    if (dest[prop] === undefined && src[prop]) {
                        dest[prop] = src[prop];
                    }
                } catch (e) { }
            }
            return dest;
        }

        function isOverlayish(el) {
            var style = el && el.style;

            if (style && /fixed|absolute/.test(style.position) && el.offsetWidth >= winWidth * 0.6 && el.offsetHeight >= winHeight * 0.75) {
                return true;
            }

            return false;
        }

        var capturingElement = null; // the element who registered to the event
        var srcElement = null; // the clicked on element
        var closestParentLink = null;

        if (window.event != null) {
            capturingElement = window.event.currentTarget;
            srcElement = window.event.srcElement;
        }

        if (srcElement != null) {
            if (srcElement.closest) {
                closestParentLink = srcElement.closest('a');
            }

            if (closestParentLink && closestParentLink.href) {
                openWndArguments[3] = closestParentLink.href;
            }
        }

        if (capturingElement == null) {
            var caller = openWndArguments.callee;
            while (caller.arguments != null && caller.arguments.callee.caller != null) {
                caller = caller.arguments.callee.caller;
            }
            if (caller.arguments != null && caller.arguments.length > 0 && caller.arguments[0].currentTarget != null) {
                capturingElement = caller.arguments[0].currentTarget;
            }
        }

        /////////////////////////////////////////////////////////////////////////////////
        // Blocked if a click on background element occurred (<body> or document)
        /////////////////////////////////////////////////////////////////////////////////
        if (capturingElement == null) {
            window.pbreason = 'Blocked a new window opened without any user interaction';
            useOriginalOpenWnd = false;
        } else if (capturingElement != null && (capturingElement instanceof Window || capturingElement === document || capturingElement.URL != null && capturingElement.body != null || capturingElement.nodeName != null && (capturingElement.nodeName.toLowerCase() == "body" || capturingElement.nodeName.toLowerCase() == "document"))) {
            window.pbreason = "Blocked a new window opened with URL: " + openWndArguments[0] + " because it was triggered by the " + capturingElement.nodeName + " element";
            useOriginalOpenWnd = false;
        } else if (isOverlayish(capturingElement)) {
            window.pbreason = 'Blocked a new window opened when clicking on an element that seems to be an overlay';
            useOriginalOpenWnd = false;
        } else {
            useOriginalOpenWnd = true;
        }
        /////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////////////////////////////
        // Block if a full screen was just initiated while opening this url.
        /////////////////////////////////////////////////////////////////////////////////
        var fullScreenElement = document.webkitFullscreenElement || document.mozFullscreenElement || document.fullscreenElement;
        if (new Date().getTime() - fullScreenOpenTime < 1000 || isNaN(fullScreenOpenTime) && isDocumentInFullScreenMode()) {

            window.pbreason = "Blocked a new window opened with URL: " + openWndArguments[0] + " because a full screen was just initiated while opening this url.";

            /* JRA REMOVED
             if (window[script_params.fullScreenFnKey]) {
             window.clearTimeout(window[script_params.fullScreenFnKey]);
             }
             */

            if (document.exitFullscreen) {
                document.exitFullscreen();
            } else if (document.mozCancelFullScreen) {
                document.mozCancelFullScreen();
            } else if (document.webkitCancelFullScreen) {
                document.webkitCancelFullScreen();
            }

            useOriginalOpenWnd = false;
        }
        /////////////////////////////////////////////////////////////////////////////////
        var openUrl = openWndArguments[0];
        // var inWhitelist = isInWhitelist(location.href);

        // if (inWhitelist) {
        //   useOriginalOpenWnd = true;
        // } else if (isInBlacklist(openUrl)) {
        //   useOriginalOpenWnd = false;
        // }

        if (useOriginalOpenWnd == true) {

            generatedWindow = originalWindowOpenFn.apply(this, openWndArguments);
            // save the window by name, for latter use.
            var windowName = getWindowName(openWndArguments);
            if (windowName != null) {
                windowsWithNames[windowName] = generatedWindow;
            }

            // 2nd line of defence: allow window to open but monitor carefully...

            /////////////////////////////////////////////////////////////////////////////////
            // Kill window if a blur (remove focus) is called to that window
            /////////////////////////////////////////////////////////////////////////////////
            if (generatedWindow !== window) {
                (function () {
                    var openTime = new Date().getTime();
                    var originalWndBlurFn = generatedWindow.blur;
                    generatedWindow.blur = function () {
                        if (new Date().getTime() - openTime < 1000 && !inWhitelist /* one second */) {
                            window.pbreason = "Blocked a new window opened with URL: " + openWndArguments[0] + " because a it was blured";
                            generatedWindow.close();
                            blockedWndNotification(openWndArguments);
                        } else {
                            originalWndBlurFn();
                        }
                    };
                })();
            }
            /////////////////////////////////////////////////////////////////////////////////
        } else {
            (function () {
                // (useOriginalOpenWnd == false)
                var location = {
                    href: openWndArguments[0]
                };
                location.replace = function (url) {
                    location.href = url;
                };

                generatedWindow = {
                    close: function close() {
                        return true;
                    },
                    test: function test() {
                        return true;
                    },
                    blur: function blur() {
                        return true;
                    },
                    focus: function focus() {
                        return true;
                    },
                    showModelessDialog: function showModelessDialog() {
                        return true;
                    },
                    showModalDialog: function showModalDialog() {
                        return true;
                    },
                    prompt: function prompt() {
                        return true;
                    },
                    confirm: function confirm() {
                        return true;
                    },
                    alert: function alert() {
                        return true;
                    },
                    moveTo: function moveTo() {
                        return true;
                    },
                    moveBy: function moveBy() {
                        return true;
                    },
                    resizeTo: function resizeTo() {
                        return true;
                    },
                    resizeBy: function resizeBy() {
                        return true;
                    },
                    scrollBy: function scrollBy() {
                        return true;
                    },
                    scrollTo: function scrollTo() {
                        return true;
                    },
                    getSelection: function getSelection() {
                        return true;
                    },
                    onunload: function onunload() {
                        return true;
                    },
                    print: function print() {
                        return true;
                    },
                    open: function open() {
                        return this;
                    },

                    opener: window,
                    closed: false,
                    innerHeight: 480,
                    innerWidth: 640,
                    name: openWndArguments[1],
                    location: location,
                    document: {
                        location: location
                    }
                };

                copyMissingProperties(window, generatedWindow);

                generatedWindow.window = generatedWindow;

                var windowName = getWindowName(openWndArguments);
                if (windowName != null) {
                    try {
                        windowsWithNames[windowName].close();
                    } catch (err) { }
                }

                var fnGetUrl = function fnGetUrl() {
                    var url = void 0;
                    if (!(generatedWindow.location instanceof Object)) {
                        url = generatedWindow.location;
                    } else if (!(generatedWindow.document.location instanceof Object)) {
                        url = generatedWindow.document.location;
                    } else if (location.href != null) {
                        url = location.href;
                    } else {
                        url = openWndArguments[0];
                    }
                    openWndArguments[0] = url;

                    blockedWndNotification(openWndArguments);
                };

                //why set timeout?  if anyone finds a reason for it, please write it here
                //in iframes it makes problems so i'm avoiding it there
                if (top == self) {
                    setTimeout(fnGetUrl, 100);
                } else {
                    fnGetUrl();
                }
            })();
        }
        return generatedWindow;
    }

    // window[originalOpenWndFnKey] = window.open; // save the original open window as global param
    function pbWindowOpen() {
        try {
            return newWindowOpenFn.apply(this, arguments);
        } catch (err) {
            return null;
        }
    }

    /////////////////////////////////////////////////////////////////////////////////
    // Replace the window open method with Poper Blocker's
    /////////////////////////////////////////////////////////////////////////////////
    window.open = pbWindowOpen;
    /////////////////////////////////////////////////////////////////////////////////

    //////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Monitor dynamic html element creation to prevent generating <a> elements with click dispatching event
    //////////////////////////////////////////////////////////////////////////////////////////////////////////
    HTMLElement.prototype.appendChild = function () {
        var newElement = originalAppendChildFn.apply(this, arguments);

        if (newElement.nodeName == 'IFRAME' && newElement.contentWindow) {
            try {
                var code = "(function () {\n" + inject.toString() + ";\n inject();\n })();";
                newElement.contentWindow.eval(code);
            } catch (e) { }
        }

        return newElement;
    };

    document.createElement = function () {

        var newElement = originalCreateElementFn.apply(document, arguments);

        if (arguments[0] == "a" || arguments[0] == "A") {
            (function () {

                timeSinceCreateAElement = new Date().getTime();

                var originalDispatchEventFn = newElement.dispatchEvent;

                newElement.dispatchEvent = function (event) {
                    if (event.type != null && ("" + event.type).toLocaleLowerCase() == "click") {
                        window.pbreason = "blocked due to an explicit dispatchEvent event with type 'click' on an 'a' tag";

                        blockedWndNotification({
                            "0": newElement.href
                        });

                        return true;
                    }

                    return originalDispatchEventFn.call(this, event);
                };

                lastCreatedAElement = newElement;
            })();
        }

        return newElement;
    };
    /////////////////////////////////////////////////////////////////////////////////


    /////////////////////////////////////////////////////////////////////////////////
    // Block artificial mouse click on frashly created <a> elements
    /////////////////////////////////////////////////////////////////////////////////
    document.createEvent = function () {
        try {
            if (arguments[0].toLowerCase().includes("mouse") && new Date().getTime() - timeSinceCreateAElement <= 50) {
                //block if the origin is not same
                var isSelfDomain = false;
                try {
                    var openUrlDomain = new URL(lastCreatedAElement.href).hostname;
                    var topUrl = window.location != window.parent.location ? document.referrer : document.location.href;
                    var topDomain = new URL(topUrl).hostname;
                    isSelfDomain = openUrlDomain == topDomain;
                } catch (e) { }
                if (lastCreatedAElement.href.trim() && !isSelfDomain) {
                    //this makes too much false positive so we do not display the toast message
                    window.pbreason = "Blocked because 'a' element was recently created and " + arguments[0] + " event was created shortly after";
                    arguments[0] = lastCreatedAElement.href;

                    blockedWndNotification({
                        "0": lastCreatedAElement.href
                    });

                    return {
                        type: 'click',
                        initMouseEvent: function initMouseEvent() { }
                    };
                }
            }

            return originalCreateEventFn.apply(document, arguments);
        } catch (err) { }
    };
    /////////////////////////////////////////////////////////////////////////////////


    /////////////////////////////////////////////////////////////////////////////////
    // Monitor full screen requests
    /////////////////////////////////////////////////////////////////////////////////
    function onFullScreen(isInFullScreenMode) {
        if (isInFullScreenMode) {
            fullScreenOpenTime = new Date().getTime();
        } else {
            fullScreenOpenTime = NaN;
        }
    }

    /////////////////////////////////////////////////////////////////////////////////

    function isDocumentInFullScreenMode() {
        // Note that the browser fullscreen (triggered by short keys) might
        // be considered different from content fullscreen when expecting a boolean
        return document.fullScreenElement && document.fullScreenElement !== null || // alternative standard methods
            document.mozFullscreenElement != null || document.webkitFullscreenElement != null; // current working methods
    }


    function blockedWndNotification(openWndArguments) {
        //this is to prevent a site that "stuck" on trying to open a new window to send endless calls to the extension
        if (!lastBlockTime || lastBlockTime < Date.now() - 1000) {
            openWndArguments["abd"] = abd;
            parentRef.postMessage({
                type: "blockedWindow",
                args: JSON.stringify(openWndArguments)
            }, parentOrigin);
        }

        lastBlockTime = Date.now();
    }

    function executeCommand(commandId, messageId) {
        if (messageId == pb_message) {
            switch (commandId) {
                case 0:
                    //off
                    window.open = originalWindowOpenFn;
                    document.createElement = originalCreateElementFn;
                    document.createEvent = originalCreateEventFn;
                    HTMLElement.prototype.appendChild = originalCreateElementFn;
                    break;
                case 1:
                    //allow once
                    allowOnce = lastBlockCaller.caller.toString();
                    lastBlockCaller.caller.apply(lastBlockCaller.caller, lastBlockCaller.args);
                    break;
            }
        }
    }

    document.addEventListener("fullscreenchange", function () {
        onFullScreen(document.fullscreen);
    }, false);

    document.addEventListener("mozfullscreenchange", function () {
        onFullScreen(document.mozFullScreen);
    }, false);

    document.addEventListener("webkitfullscreenchange", function () {
        onFullScreen(document.webkitIsFullScreen);
    }, false);

    (function () {
        window.pbExternalCommand = function (commandId, messageId) {
            executeCommand(commandId, messageId);
        };
    })();
}

function parseDomain(url) {
    var domain;
    //find & remove protocol (http, ftp, etc.) and get domain
    if (url.indexOf("://") > -1) {
        domain = url.split('/')[2];
    } else {
        domain = url.split('/')[0];
    }
    //find & remove port number
    domain = domain.split(':')[0];
    domain = domain.replace("www.", "");
    return domain;
}
