$(document).ready(function(){
    var langCode = navigator.language.substr(0, 2);

    var linksByLang = {
        fr: "https://trustnav.typeform.com/to/jX5FOF",
        pt: "https://trustnav.typeform.com/to/rNBE5E",
        es: "https://trustnav.typeform.com/to/JcZziQ",
        en: "https://trustnav.typeform.com/to/aNV7p2",
    };

    $("[js-questionnaire-link]").attr("href", linksByLang[langCode] || linksByLang['en']);

    $("[js-close-modal]").click(function(){
        closeIframe();
    });

    $("[js-questionnaire-link]").click(function () {
        closeIframe();
    });

    $("[js-rate-us]").click(function () {
        closeIframe();
    });

    $("[js-yes-vote]").click(function() {
        $("[js-question-section]").hide();
        $("[js-rate-section]").fadeIn();
    });

    var closeIframe = function () {
        parent.postMessage({
            message: 'trustnav_close_iframe',
            toClose: '#questionnaire-iframe'
        }, '*');
    }

});
