chrome.runtime.sendMessage({
    'action': 'getAdblockerStats'
}, function (response) {
    $('#limited-blocked-today-max').html(response.blocked.max);
});