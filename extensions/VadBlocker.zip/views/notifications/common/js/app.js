$(document).ready(function () {
    $('[js-close]').click(function () {
        parent.postMessage({
            message: 'trustnav_close_adb_iframe'
        }, '*');
    });

    $("[js-account-url-prefix]").each(function () {
        var fullUrl = configServer.accountUrl + $(this).attr('href');
        $(this).attr('href', fullUrl);
    });
});