chrome.runtime.sendMessage({
    'action': 'getActivePlan'
}, function (response) {
    if (response && response.remainingDays >= 0) {
        $("[js-remaining-days]").html(response.remainingDays);
    }
});
