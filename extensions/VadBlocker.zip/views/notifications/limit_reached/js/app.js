chrome.runtime.sendMessage({
    'action': 'getAdblockerStats'
}, function (response) {
    $('#limited-blocked-today-amount').html(response.blocked.amount);
    $('#limited-blocked-today-max').html(response.blocked.max);
    $('#limited-blocked-today-left').html(response.blocked.left);

    if (response.blocked.left === 0) {
        $('#limited-blocked-today-time-left').show();
        setTimer();
    }
});

/**
 * Setea el timer de tiempo restante para volver a bloquear anuncios
 */
var setTimer = function () {
    var now = new Date();
    var currentHour = now.getHours();
    var currentMinutes = now.getMinutes();

    var hoursRemaining = 24 - 1 - currentHour; // se resta una 
    var minutesRemaining = 60 - currentMinutes;

    var timeRemaining = '';
    // Si es menos de 10, se agrega el 0 para mantener formato
    timeRemaining += hoursRemaining < 10 ? '0' + hoursRemaining : hoursRemaining;
    timeRemaining += ':';
    timeRemaining += minutesRemaining < 10 ? '0' + minutesRemaining : minutesRemaining;
    timeRemaining += 'h';

    // Actualizar la vista
    $('#limited-blocked-time-left').html(timeRemaining);

    // Actualizar el contador en 10 segundos
    setTimeout(setTimer, 10000);
};