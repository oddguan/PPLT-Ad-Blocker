/* Variables para inicializar */
var rating;
var generalStatus = 1;
var disabledByLimit = false;
var siteStatus = 1;
var blockedUrl = 0;
var loggedUser;
var loginUrl = configServer.accountsDomain + "/login-extension";
var userPanelUrl = configServer.accountsDomain + "/trustnav-admin-public";
var uid = "";

var updateSiteStatusUI = function () {
    /* Si la URL no es valida, oculto todo y corto */
    if (blockedUrl) {
        $("#blocked-ads-row").addClass("hidden");
        $("#site-toggle").addClass("hidden");
        $("#site-toggle").addClass("hidden");
    }
    /* Si URL valida o no me mando ningun URL, hago lo normal */
    else {
        /* Desactivar */
        if (!siteStatus) {
            $("#site-enabled-icon").addClass('hidden');
            $("#site-enabled-text").addClass('hidden');
            $("#site-disabled-icon").removeClass('hidden');
            $("#site-disabled-text").removeClass('hidden');
            /* Ocultar row de anuncios bloqueados */
            $("#blocked-ads-row").addClass('hidden');
        }
        /* Activar */
        else {
            $("#site-enabled-icon").removeClass('hidden');
            $("#site-enabled-text").removeClass('hidden');
            $("#site-disabled-icon").addClass('hidden');
            $("#site-disabled-text").addClass('hidden');
            /* Mostrar row de anuncios bloqueados */
            if (generalStatus)
                $("#blocked-ads-row").removeClass('hidden');
        }
    }

};

var checkLogged = function () {
    chrome.runtime.sendMessage({
        action: 'checkLogged'
    }, function (response) {
        if (response.logged) {
            loggedUser = response;
            $(".my-account-name").html(loggedUser.name);
            $(".my-account-edit-field > span").eq(0).html(loggedUser.email);
            $(".my-account-logged").show();
            $(".my-account-logout").hide();

            if (loggedUser.picture) {
                $(".circle-img-container").attr('src', loggedUser.picture);
                $("#account-avatar").show();
                $("#placeholder-avatar").hide();
            } else {
                $("#placeholder-avatar span").html(loggedUser.name[0].toUpperCase());
                $("#account-avatar").hide();
                $("#placeholder-avatar").show();
            }

            $("#login").hide();
            $("#account").show();
            $("#blocker-wrap").hide();
        } else {
            uid = response.uid;
            loggedUser = false;
            $("#login").show();
            $("#account").hide();
            $("#blocker-wrap").hide();
        }
    });
};

var updateGeneralStatusUI = function () {
    $("#share").hide();
    $("#settings").hide();
    $("#unlimited").hide();

    /* Desactivar */
    if (!generalStatus) {
        /* Oculto boton de apagado */
        $("[shutdown-trustnav]").eq(0).hide();
        $("[shutdown-trustnav]").eq(2).hide();
        /* Oculto wrap principal de estado encendido */
        $("#trustnav-on").hide();
        /* Set de switch en setting */
        $("[shutdown-trustnav-switch]").removeClass("on");
        $("[shutdown-trustnav-switch]").addClass("off");
        /* Muestro wrap principal de estado apagado */
        $("#trustnav-off").show();
        $("#blocker-wrap").show();
    } else {
        /* Oculto wrap principal de estado apagado */
        $("#trustnav-off").hide();
        /* Muestro boton de apagado */
        $("[shutdown-trustnav]").eq(0).show();
        $("[shutdown-trustnav]").eq(2).show();
        /* Si no es una URL bloqueada, muestro row de site-toggle */
        $("[site-blocker-status]").addClass(siteStatus ? 'on' : 'off');
        /* Set de switch en setting */
        $("[shutdown-trustnav-switch]").removeClass("off");
        $("[shutdown-trustnav-switch]").addClass("on");
        /* Muestro wrap principal de estado encendido */
        $("#trustnav-on").show();
        // Si esta deshabilitado por limite aplico estilos de deshabilitado
        if (disabledByLimit) {
            $("#trustnav-on").addClass("limit-reached");
            $("[shutdown-trustnav]").eq(0).hide();
            $("[shutdown-trustnav]").eq(2).hide();
            $("[settings-toggle]").hide();
        }
    }
};


chrome.runtime.sendMessage({
    'action': 'getAdblockerStats'
}, function (response) {
    // Si es null, esta ilimitado
    if (response.blocked.max === null) {
        $('#unlimited-blocked-today-amount').html(response.blocked.amount);
        // drawArc("#backgroundArc2", 125, 115, 100, 100);
        drawArc("#progressArc2", 125, 115, 100, 100);
        $('#unlimited-blocked-today-amount').html(response.blocked.amount);
        $('#trustnav-unlimited').show();
    } else {
        $('#limited-blocked-today-amount').html(response.blocked.amount);
        $('#limited-blocked-today-max').html(response.blocked.max);
        $('#limited-blocked-today-left').html(response.blocked.left);

        if (response.blocked.left === 0) {
            $('#limited-blocked-today-time-left').show();
            setTimer();
        }

        var percentage = Math.floor(response.blocked.amount / response.blocked.max * 100);
        if (percentage > 100) {
            percentage = 100;
        }
        drawArc("#backgroundArc", 125, 115, 100, 100);
        drawArc("#progressArc", 125, 115, 100, percentage);
        $('#trustnav-limited').show();
    }
});

/**
 * Setea el timer de tiempo restante para volver a bloquear anuncios
 */
var setTimer = function () {
    var now = new Date();
    var currentHour = now.getHours();
    var currentMinutes = now.getMinutes();

    var hoursRemaining = 24 - 1 - currentHour; // se resta una 
    var minutesRemaining = 60 - currentMinutes;

    var timeRemaining = '';
    // Si es menos de 10, se agrega el 0 para mantener formato
    timeRemaining += hoursRemaining < 10 ? '0' + hoursRemaining : hoursRemaining;
    timeRemaining += ':';
    timeRemaining += minutesRemaining < 10 ? '0' + minutesRemaining : minutesRemaining;
    timeRemaining += 'h';

    // Actualizar la vista
    $('#limited-blocked-time-left').html(timeRemaining);

    // Actualizar el contador en 10 segundos
    setTimeout(setTimer, 10000);
};

var setCounter = function (page) {
    chrome.runtime.sendMessage({
        'action': 'getCounter',
        'data': {
            id: page.id
        },
    }, function (response) {
        $("#adsBlocked").text(response.count);
    });
};

var sendRating = function (safe) {
    chrome.tabs.getSelected(null, function (tab) {
        var domain = parseDomain(tab.url);
        rating.user = safe;
        chrome.runtime.sendMessage({
            action: 'sendRating',
            domain: domain,
            safe: safe
        }, function (response) {
            //
        });
    });
};

var logout = function () {
    $(".logout-wrap").hide();
    $(".my-account-logged").hide();
    $(".my-account-logout").show();

    chrome.runtime.sendMessage({
        action: 'logout',
    }, function (response) {
        checkLogged();
    })
}


// Agrega como prefijo del href el dominio de las pantallas 'Accounts' 
var addAccountUrlPrefix = function () {
    $("[js-account-url-prefix]").each(function () {
        var fullUrl = configServer.accountUrl + $(this).attr('href');
        $(this).attr('href', fullUrl);
    });
}


/* Encender / apagar trustnav */
$("[shutdown-trustnav]").click(function () {
    generalStatus = parseInt($(this).attr("shutdown-trustnav"));
    updateGeneralStatusUI();

    /* Le pido al background que setee el estado */
    chrome.runtime.sendMessage({
        'action': 'setBlockerStatus',
        'status': generalStatus
    }, function (response) {});
});


/* Entrar en modo settings */
$("[settings-toggle]").click(function () {
    $("#blocker-wrap").hide();
    $("#settings").show();
});

/* Entrar en modo profile */
$("[profile-toggle]").click(function () {
    checkLogged();
});

var changeSwitch = function (selector, status) {
    if (status) {
        $(selector).removeClass('off');
        $(selector).addClass('on');
    } else {
        $(selector).removeClass('on');
        $(selector).addClass('off');
    }
}

/* Funcionamiento de tabs */
$(document).on("click", ".tabs-triggers > div", function () {
    var tabTrigger = $(this).attr("tab-toggle");
    $(".tabs-triggers > div.selected").removeClass("selected");
    $(this).addClass("selected");

    $("#authorizedAds").hide();
    $("#authorizedPopups").hide();

    $("#" + tabTrigger).show();
});


/* Encender/apagar trustnav a travez de switch en settings */
$(document).on("click", "[shutdown-trustnav-switch]", function () {
    generalStatus = !$(this).hasClass("on");

    /* Le pido al background que setee el estado */
    chrome.runtime.sendMessage({
        'action': 'setBlockerStatus',
        'status': generalStatus
    }, function (response) {
        if (generalStatus) {
            $("[shutdown-trustnav]").eq(0).show();
            $("[shutdown-trustnav]").eq(2).show();
            $("#trustnav-on").show();
            $("#trustnav-off").hide();
        } else {
            $("[shutdown-trustnav]").eq(0).hide();
            $("[shutdown-trustnav]").eq(2).hide();
            $("#trustnav-on").hide();
            $("#trustnav-off").show();
        }

        changeSwitch("[shutdown-trustnav-switch]", generalStatus);
    });
});

/* Click en cambio de estado de sitio */
$("[site-blocker-status]").click(function () {
    /* Cambiar estado */
    siteStatus = !siteStatus;
    // updateSiteStatusUI();
    /* Le pido al background que setee el estado */
    ext.pages.query({
        active: true,
        lastFocusedWindow: true
    }, function (pages) {
        page = pages[0];
        if (page && page.url) {
            var domain = parseDomain(page.url.href);
            chrome.runtime.sendMessage({
                'action': 'setBlockerStatus',
                'status': siteStatus,
                'domain': domain
            }, function (response) {
                $("#sites-blocked").html("");
                updateAuthorizedAdsUI();
                changeSwitch("[site-blocker-status]", siteStatus);
            });
        }
    })
});

/* Click en DOMINIO DE LA LISTA DE SITIOS AUTORIZADOS */
$(document).on("click", "#sites-blocked > div", function () {
    var domain = $(this).attr("site");
    var that = this;

    ext.pages.query({
        active: true,
        lastFocusedWindow: true
    }, function (pages) {
        page = pages[0];

        chrome.runtime.sendMessage({
            'action': 'setBlockerStatus',
            'status': true,
            'domain': domain
        }, function () {

            if (domain == parseDomain(page.url.href)) {
                siteStatus = true;
                $("[site-blocker-status]").removeClass('off');
                $("[site-blocker-status]").addClass('on');
            }

            $(that).remove();

            if ($("#sites-blocked").find(".option-wrap").length) {
                $("#noAuthorized").hide();
            } else {
                $("#noAuthorized").show();
            }

        });
    });


});

$(document).on("click", ".facebook-btn", function () {
    var url = configServer.accountUrl + '/login?action=login&social_provider=facebook';
    window.open(url);
});

$(document).on("click", ".google-btn", function () {
    var url = configServer.accountUrl + '/login?action=login&social_provider=google';
    window.open(url);
});

$(document).on("submit", "#login-form", function (e) {
    e.preventDefault();
    var email = $('#login-email').val();
    var url = configServer.accountUrl + '/login?action=login&email=' + encodeURIComponent(email);
    window.open(url);
});

$(document).on("click", "[popup-alert-switch]", function () {
    var isChecked = $(this).hasClass('on');
    chrome.runtime.sendMessage({
        action: 'setPopUpNotificationStatus',
        status: isChecked
    }, function (response) {
        changeSwitch("[popup-alert-switch]", !isChecked);
    });
});

$(document).on("click", "#sites-popup-enable > div", function () {
    var domain = $(this).attr("site");
    var that = this;
    chrome.runtime.sendMessage({
        action: 'setPopUpNotificationStatus',
        domains: [domain],
        status: false
    }, function (response) {
        $(that).remove();

        if ($("#sites-popup-enable").find(".option-wrap").length) {
            $("#noPopUpNotificationText").hide();
        } else {
            $("#noPopUpNotificationText").show();
        };

    });
});

/* CLick en switch de ads intrusivos */
$(document).on("click", "[intrusive-ads-switch]", function () {
    var isChecked = !$(this).hasClass("on");
    if (isChecked) {
        addSubscription('https://easylist-downloads.adblockplus.org/exceptionrules.txt', 'Allow non-intrusive advertising', 'https://easylist-downloads.adblockplus.org/exceptionrules.txt');
    } else {
        removeSubscription('https://easylist-downloads.adblockplus.org/exceptionrules.txt');
    }

    setTimeout(function () {
        changeSwitch("[intrusive-ads-switch]", isChecked);
    }, 100);
});


/* Click en go back de settings */
$(document).on("click", "[go-back]", function () {
    $("#settings").hide();
    $("#login").hide();
    $("#account").hide();
    $("#blocker-wrap").show();
});

$(document).on("click", ".logout-wrap", function () {
    logout();
})

$(document).on("click", ".advanced-option > .bold", function () {
    $("#advanced-option").toggle();
    $("#chevronDown").toggleClass("rotate");
});

/* Init */
$(document).ready(function () {
    updateSiteStatusUI();
    getSettingData();
    addAccountUrlPrefix();

    chrome.tabs.query({
        active: true
    }, function (tabs) {
        var tab = tabs[0];
        var domain = parseDomain(tab.url);
        var validUrl = validateUrl(tab.url);

        if (!validUrl) {
            $("[site-blocker-status]").parent().hide();
        }

        /* Obtengo el estado del bloqueador */
        chrome.runtime.sendMessage({
            'action': 'getBlockerStatus',
            'domain': validUrl ? domain : undefined
        }, function (response) {
            siteStatus = response.domain;
            generalStatus = response.general;

            if (!response.general && response.limitReached) {
                generalStatus = true;
                disabledByLimit = true;
            }

            updateGeneralStatusUI();
            updateSiteStatusUI(validUrl);
        })
    });

});

/* Actualizar contador de bloqueos */
ext.pages.query({
    active: true,
    lastFocusedWindow: true
}, function (pages) {
    var page = pages[0];
    if (page)
        setCounter(page);
});


function drawArc(element, cx, cy, radius, anglePercent, animated) {
    var svgns = 'http://www.w3.org/2000/svg';
    var circle = $(element)[0];
    var d = " M " + (cx - radius) + " " + cy;
    var angle = -180;
    var maxAngle = Math.round(anglePercent * 180 / 100) - 180;


    if (animated) {
        var animatedArcInterval = setInterval(function () {
            var radians = angle * (Math.PI / 180);
            var x = cx + Math.cos(radians) * radius;
            var y = cy + Math.sin(radians) * radius;
            var actualPercent = Math.round((angle * 100) / -180);
            d += " L " + x + " " + y;

            circle.setAttribute("d", d)

            if (angle == maxAngle) {
                clearInterval(animatedArcInterval);
            } else {
                angle++;
            }

        }, 10);
    } else {
        while (angle < maxAngle) {
            var radians = angle * (Math.PI / 180);
            var x = cx + Math.cos(radians) * radius;
            var y = cy + Math.sin(radians) * radius;
            d += " L " + x + " " + y;

            angle++;
        }


        circle.setAttribute("d", d)
    }

}