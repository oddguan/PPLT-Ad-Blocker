/********************************************************************************************************************************
Helper.js

Helper es un objeto que contendra las funciones que sean de ayuda a la hora de codificar y no repetir codigo.

*********************************************************************************************************************************/

/**
 * @function validateUrl();
 * @param {object} url
 * @desc Funcion que valida una url pasada a travez de unas variables propias de bloqueo, de esta forma ahorramos generar eventos basura en urls del tipo about:blank o chrome://extensions
 *
 */

function validateUrl(url) {
    var parsedUrl = new URL(url);
    var toBlock = {
        blockedProtocol : [
            "about:",
            "chrome:",
            "chrome-extension:"
        ],
        blockedHostname : [
            "localhost",
            "newtab"
        ]
    }

    if (toBlock.blockedProtocol.indexOf(parsedUrl.protocol) == - 1 && toBlock.blockedHostname.indexOf(parsedUrl.hostname) == -1) {
        return true;
    } else {
        return false;
    }
}

/**
 * @function parseDomain
 * @param {object} domain
 * @desc parsea el dominio eliminando https, http, www.
 *
 */

function parseDomain(url) {
    var domain;
    //find & remove protocol (http, ftp, etc.) and get domain
    if (url.indexOf("://") > -1) {
        domain = url.split('/')[2];
    }
    else {
        domain = url.split('/')[0];
    }
    //find & remove port number
    domain = domain.split(':')[0];
    domain = domain.replace("www.", "");
    return domain;
}

function wrapper(baseMessage /* , [paramKeys] */)
{
  var paramKeys = [];
  for (var i = 1; i < arguments.length; i++)
    paramKeys.push(arguments[i]);

  return function(/* [paramValues], callback */)
  {
    var message = Object.create(null);
    for (var key in baseMessage)
      if (baseMessage.hasOwnProperty(key))
        message[key] = baseMessage[key];

    var paramValues = [];
    var callback;

    if (arguments.length > 0)
    {
      var lastArg = arguments[arguments.length - 1];
      if (typeof lastArg == "function")
        callback = lastArg;

      for (var i = 0; i < arguments.length - (callback ? 1 : 0); i++)
        message[paramKeys[i]] = arguments[i];
    }

    // Chrome 30 throws an exception when sendMessage is called with a callback
    // parameter of undefined, so we work around that here. (See issue 4052)
    if (callback)
      ext.backgroundPage.sendMessage(message, callback);
    else
      ext.backgroundPage.sendMessage(message);
  };
}



var getSubscriptions = wrapper({type: "subscriptions.get"}, "downloadable", "special");
var getFilters = wrapper({type: "filters.get"}, "subscriptionUrl");
var whitelistedDomainRegexp = /^@@\|\|([^\/:]+)\^\$document$/;
var removeSubscription = wrapper({type: "subscriptions.remove"}, "url");
var addSubscription = wrapper({type: "subscriptions.add"}, "url", "title", "homepage");


function convertSpecialSubscription(subscription) {
    getFilters(subscription.url, function(filters) {
        for (var j = 0; j < filters.length; j++) {
            var filter = filters[j].text;
            if (filter.indexOf('trustnav.com') < 0 && filter.indexOf('*') < 0) {
                if (whitelistedDomainRegexp.test(filter)) {
                    filter = filter.replace("@@||", "").replace("^$document", "");
                    var html = '<div site="'+filter+'" class="option-wrap on">' +
                                    '<div class="option-name">' +
                                        filter +
                                    '</div>' +
                                    '<div class="option-switch">' +
                                        '<div class="track"></div>' +
                                        '<div class="knob"></div>' +
                                    '</div>' +
                                '</div>';
                    $("#sites-blocked").append(html);
                }
            }
        }

        if ($("#sites-blocked").find(".option-wrap").length) {
            $("#noAuthorized").hide();
        }else {
            $("#noAuthorized").show();
        }
    });
}

var updateAuthorizedAdsUI = function() {
    getSubscriptions(false, true, function(subscriptions) {
        for (var i = 0; i < subscriptions.length; i++) {
            convertSpecialSubscription(subscriptions[i]);
        }

    });
};


var getIntrusiveAdStatus = function() {
    getSubscriptions(true, false, function(subscriptions)
	{
        subscriptions.forEach(function(subscription){
			if(subscription && !subscription.disabled){
				/* Bypassear la de anuncios aceptables */
				if (subscription.url == 'https://easylist-downloads.adblockplus.org/exceptionrules.txt') {
                    $("[intrusive-ads-switch]").addClass("on");
                    $("[intrusive-ads-switch]").removeClass("off");
                	// $("#block-only-intrusive-ads").attr('checked', true);
				}
			}
		});
	});
};

var updatePopupsAuthorizedUI = function() {
    chrome.runtime.sendMessage({action: 'getPopUpNotificationStatus'}, function(response) {
        $("[popup-alert-switch]").addClass(response && response.status ? 'on' : 'off');
    });

    chrome.runtime.sendMessage({ action: 'getPopUpDisabledNotification' }, function(response) {
        if (response && response.domains && response.domains.length) {
            $("#noPopUpNotificationText").hide();

            for (var domain of response.domains) {
                var html = '<div site="'+domain+'" class="option-wrap on">' +
                                '<div class="option-name">' +
                                    domain +
                                '</div>' +
                                '<div class="option-switch">' +
                                    '<div class="track"></div>' +
                                    '<div class="knob"></div>' +
                                '</div>' +
                            '</div>';

                $("#sites-popup-enable").append(html);
            }
        } else {
            $("#noPopUpNotificationText").show();
        }
    });
};

var getSettingData = function() {
    updateAuthorizedAdsUI();
    getIntrusiveAdStatus();
    updatePopupsAuthorizedUI();
}
